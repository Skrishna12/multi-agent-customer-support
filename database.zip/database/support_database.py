import sqlite3
import json
from datetime import datetime


DATABASE_FILE = "database/support_system.db"


class SupportDatabase:

    def __init__(self, database_file=DATABASE_FILE):
        self.database_file = database_file
        self.create_tables()

    def get_connection(self):
        return sqlite3.connect(self.database_file)

    # =========================================================
    # CREATE DATABASE TABLES
    # =========================================================

    def create_tables(self):

        conn = self.get_connection()
        cursor = conn.cursor()

        # =====================================================
        # TICKETS TABLE
        # =====================================================

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tickets (

                id INTEGER PRIMARY KEY AUTOINCREMENT,

                ticket_text TEXT NOT NULL,

                order_id TEXT,

                category TEXT,

                category_confidence REAL,

                priority TEXT,

                priority_confidence REAL,

                sentiment TEXT,

                sentiment_confidence REAL,

                response TEXT,

                escalation_decision TEXT,

                escalation_score REAL,

                escalation_reasons TEXT,

                created_at TEXT
            )
        """)

        # =====================================================
        # RETRIEVAL LOG TABLE
        # =====================================================

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS retrieval_logs (

                id INTEGER PRIMARY KEY AUTOINCREMENT,

                ticket_id INTEGER,

                source_type TEXT,

                source_id TEXT,

                category TEXT,

                similarity_score REAL,

                resolution TEXT,

                FOREIGN KEY(ticket_id)
                    REFERENCES tickets(id)
            )
        """)

        # =====================================================
        # FEEDBACK TABLE
        # =====================================================

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS feedback (

                id INTEGER PRIMARY KEY AUTOINCREMENT,

                ticket_id INTEGER,

                helpful INTEGER,

                resolved INTEGER,

                customer_satisfaction REAL,

                comments TEXT,

                created_at TEXT,

                FOREIGN KEY(ticket_id)
                    REFERENCES tickets(id)
            )
        """)

        # =====================================================
        # AGENT EXECUTION LOG TABLE
        # =====================================================

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS agent_logs (

                id INTEGER PRIMARY KEY AUTOINCREMENT,

                ticket_id INTEGER,

                agent_name TEXT NOT NULL,

                status TEXT NOT NULL,

                output_summary TEXT,

                started_at TEXT,

                completed_at TEXT,

                FOREIGN KEY(ticket_id)
                    REFERENCES tickets(id)
            )
        """)

        conn.commit()
        conn.close()

    # =========================================================
    # SAVE COMPLETE TICKET RESULT
    # =========================================================

    def save_ticket(self, result):

        conn = self.get_connection()
        cursor = conn.cursor()

        try:
            intake = result["intake"]
            classification = result["classification"]
            sentiment = result["sentiment"]
            escalation = result["escalation"]

            # -------------------------------------------------
            # Safely extract order ID
            # -------------------------------------------------

            entities = intake.get("entities", {}) or {}

            order_id = entities.get("order_id")

            # -------------------------------------------------
            # Safely extract escalation score
            #
            # Current EscalationAgent returns "score".
            # Older versions used "escalation_score".
            # Support both so the database remains compatible.
            # -------------------------------------------------

            escalation_score = escalation.get(
                "escalation_score",
                escalation.get("score", 0)
            )

            # -------------------------------------------------
            # Safely extract escalation reasons
            # -------------------------------------------------

            escalation_reasons = escalation.get(
                "reasons",
                []
            )

            # -------------------------------------------------
            # Response may be either:
            #   1. a string
            #   2. a dictionary from the LLM Response Agent
            #
            # Store only the actual customer-facing response.
            # -------------------------------------------------

            response_data = result.get("response", "")

            if isinstance(response_data, dict):
                response_text = response_data.get(
                    "response",
                    ""
                )
            else:
                response_text = str(response_data)

            # -------------------------------------------------
            # INSERT TICKET
            # -------------------------------------------------

            cursor.execute("""
                INSERT INTO tickets (
                    ticket_text,
                    order_id,
                    category,
                    category_confidence,
                    priority,
                    priority_confidence,
                    sentiment,
                    sentiment_confidence,
                    response,
                    escalation_decision,
                    escalation_score,
                    escalation_reasons,
                    created_at
                )

                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (

                result["ticket"],

                order_id,

                classification.get("category"),

                classification.get(
                    "category_confidence"
                ),

                classification.get("priority"),

                classification.get(
                    "priority_confidence"
                ),

                sentiment.get("sentiment"),

                sentiment.get("confidence"),

                response_text,

                escalation.get("decision"),

                escalation_score,

                json.dumps(
                    escalation_reasons
                ),

                datetime.now().isoformat()
            ))

            ticket_id = cursor.lastrowid

            # =================================================
            # SAVE RETRIEVAL RESULTS
            # =================================================

            retrieval_results = result.get(
                "retrieval",
                []
            )

            if retrieval_results:

                for item in retrieval_results:

                    cursor.execute("""
                        INSERT INTO retrieval_logs (
                            ticket_id,
                            source_type,
                            source_id,
                            category,
                            similarity_score,
                            resolution
                        )

                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (

                        ticket_id,

                        item.get("source_type"),

                        item.get("source_id"),

                        item.get("category"),

                        item.get("similarity_score"),

                        item.get("resolution")
                    ))

            conn.commit()

            return ticket_id

        except Exception:

            conn.rollback()

            raise

        finally:

            conn.close()

    # =========================================================
    # SAVE AGENT EXECUTION LOG
    # =========================================================

    def save_agent_log(
        self,
        ticket_id,
        agent_name,
        status,
        output_summary="",
        started_at=None,
        completed_at=None
    ):
        """
        Store an actual agent execution record.
        """

        if started_at is None:
            started_at = datetime.now().isoformat()

        if completed_at is None:
            completed_at = datetime.now().isoformat()

        conn = self.get_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                INSERT INTO agent_logs (
                    ticket_id,
                    agent_name,
                    status,
                    output_summary,
                    started_at,
                    completed_at
                )

                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                ticket_id,
                agent_name,
                status,
                output_summary,
                started_at,
                completed_at
            ))

            conn.commit()

            return cursor.lastrowid

        finally:

            conn.close()

    # =========================================================
    # GET AGENT LOGS
    # =========================================================

    def get_agent_logs(self, ticket_id):

        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                id,
                ticket_id,
                agent_name,
                status,
                output_summary,
                started_at,
                completed_at
            FROM agent_logs
            WHERE ticket_id = ?
            ORDER BY id ASC
        """, (ticket_id,))

        rows = cursor.fetchall()

        conn.close()

        logs = []

        for row in rows:

            logs.append({
                "id": row[0],
                "ticket_id": row[1],
                "agent_name": row[2],
                "status": row[3],
                "output_summary": row[4],
                "started_at": row[5],
                "completed_at": row[6]
            })

        return logs

    # =========================================================
    # GET RETRIEVAL LOGS
    # =========================================================

    def get_retrieval_logs(self, ticket_id):

        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                id,
                ticket_id,
                source_type,
                source_id,
                category,
                similarity_score,
                resolution
            FROM retrieval_logs
            WHERE ticket_id = ?
            ORDER BY similarity_score DESC
        """, (ticket_id,))

        rows = cursor.fetchall()

        conn.close()

        logs = []

        for row in rows:

            logs.append({
                "id": row[0],
                "ticket_id": row[1],
                "source_type": row[2],
                "source_id": row[3],
                "category": row[4],
                "similarity_score": row[5],
                "resolution": row[6]
            })

        return logs

    # =========================================================
    # SAVE CUSTOMER FEEDBACK
    # =========================================================

    def save_feedback(
        self,
        ticket_id,
        helpful,
        resolved,
        customer_satisfaction,
        comments=""
    ):

        conn = self.get_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                INSERT INTO feedback (
                    ticket_id,
                    helpful,
                    resolved,
                    customer_satisfaction,
                    comments,
                    created_at
                )

                VALUES (?, ?, ?, ?, ?, ?)
            """, (

                ticket_id,
                helpful,
                resolved,
                customer_satisfaction,
                comments,
                datetime.now().isoformat()
            ))

            conn.commit()

        finally:

            conn.close()

    # =========================================================
    # GET FEEDBACK
    # =========================================================

    def get_feedback(self, ticket_id):

        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                id,
                ticket_id,
                helpful,
                resolved,
                customer_satisfaction,
                comments,
                created_at
            FROM feedback
            WHERE ticket_id = ?
            ORDER BY id DESC
        """, (ticket_id,))

        rows = cursor.fetchall()

        conn.close()

        feedback = []

        for row in rows:

            feedback.append({
                "id": row[0],
                "ticket_id": row[1],
                "helpful": row[2],
                "resolved": row[3],
                "customer_satisfaction": row[4],
                "comments": row[5],
                "created_at": row[6]
            })

        return feedback

    # =========================================================
    # GET TICKET
    # =========================================================

    def get_ticket(self, ticket_id):

        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT *
            FROM tickets
            WHERE id = ?
        """, (ticket_id,))

        result = cursor.fetchone()

        conn.close()

        return result

    # =========================================================
    # GET TICKET COUNT
    # =========================================================

    def get_ticket_count(self):

        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT COUNT(*)
            FROM tickets
        """)

        count = cursor.fetchone()[0]

        conn.close()

        return count

    # =========================================================
    # GET AGENT LOG COUNT
    # =========================================================

    def get_agent_log_count(self):

        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT COUNT(*)
            FROM agent_logs
        """)

        count = cursor.fetchone()[0]

        conn.close()

        return count


# =============================================================
# TEST DATABASE
# =============================================================

if __name__ == "__main__":

    database = SupportDatabase()

    print("\n" + "=" * 60)
    print("SUPPORT DATABASE")
    print("=" * 60)

    print("\nDatabase initialized successfully.")

    print(
        "Tickets stored:",
        database.get_ticket_count()
    )

    print(
        "Agent logs stored:",
        database.get_agent_log_count()
    )