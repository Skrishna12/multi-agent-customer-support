import pandas as pd
import faiss
import numpy as np

from sentence_transformers import SentenceTransformer


# ==========================================
# CONFIGURATION
# ==========================================

FAQ_FILE = "data/faq_knowledge_base_150.csv"
TICKET_FILE = "data/support_tickets_10k.csv"

INDEX_FILE = "rag/support_knowledge.index"
METADATA_FILE = "rag/support_knowledge_metadata.csv"

MODEL_NAME = "all-MiniLM-L6-v2"


# ==========================================
# 1. LOAD DATA
# ==========================================

print("Loading datasets...")

faqs = pd.read_csv(FAQ_FILE)
tickets = pd.read_csv(TICKET_FILE)

print("FAQs:", len(faqs))
print("Tickets:", len(tickets))


# ==========================================
# 2. PREPARE FAQ DOCUMENTS
# ==========================================

faq_documents = []

for _, row in faqs.iterrows():

    document = (
        "Type: FAQ\n"
        f"FAQ ID: {row['faq_id']}\n"
        f"Category: {row['category']}\n"
        f"Question: {row['question']}\n"
        f"Answer: {row['answer']}"
    )

    faq_documents.append({
        "source_type": "FAQ",
        "source_id": row["faq_id"],
        "category": row["category"],
        "text": document,
        "resolution": row["answer"]
    })


# ==========================================
# 3. PREPARE RESOLVED TICKETS
# ==========================================

ticket_documents = []

for _, row in tickets.iterrows():

    document = (
        "Type: Resolved Support Ticket\n"
        f"Ticket ID: {row['ticket_id']}\n"
        f"Category: {row['ticket_category']}\n"
        f"Priority: {row['priority']}\n"
        f"Customer Issue: {row['ticket_text']}\n"
        f"Resolution: {row['resolution_text']}"
    )

    ticket_documents.append({
        "source_type": "TICKET",
        "source_id": row["ticket_id"],
        "category": row["ticket_category"],
        "text": document,
        "resolution": row["resolution_text"]
    })


# ==========================================
# 4. COMBINE KNOWLEDGE
# ==========================================

documents = faq_documents + ticket_documents

print("\nTotal documents:", len(documents))

texts = [
    document["text"]
    for document in documents
]


# ==========================================
# 5. LOAD EMBEDDING MODEL
# ==========================================

print("\nLoading embedding model...")

model = SentenceTransformer(MODEL_NAME)

print("Embedding model loaded.")


# ==========================================
# 6. CREATE EMBEDDINGS
# ==========================================

print("\nCreating embeddings...")

embeddings = model.encode(
    texts,
    show_progress_bar=True,
    convert_to_numpy=True
)


# ==========================================
# 7. NORMALIZE EMBEDDINGS
# ==========================================

embeddings = embeddings.astype("float32")

faiss.normalize_L2(embeddings)


# ==========================================
# 8. CREATE FAISS INDEX
# ==========================================

dimension = embeddings.shape[1]

print("\nEmbedding dimension:", dimension)

index = faiss.IndexFlatIP(dimension)

index.add(embeddings)


# ==========================================
# 9. SAVE INDEX
# ==========================================

faiss.write_index(
    index,
    INDEX_FILE
)


# ==========================================
# 10. SAVE METADATA
# ==========================================

metadata = pd.DataFrame(documents)

metadata.to_csv(
    METADATA_FILE,
    index=False
)


# ==========================================
# 11. SUMMARY
# ==========================================

print("\n" + "=" * 60)
print("RAG KNOWLEDGE BASE CREATED")
print("=" * 60)

print("Documents indexed:", index.ntotal)

print("FAISS index:")
print(INDEX_FILE)

print("\nMetadata:")
print(METADATA_FILE)

print("\nRAG setup complete!")