import os
import sys

import faiss
import pandas as pd
from sentence_transformers import SentenceTransformer


# ============================================================
# PROJECT PATH
# ============================================================

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

if PROJECT_ROOT not in sys.path:
    sys.path.append(PROJECT_ROOT)


# ============================================================
# RETRIEVAL AGENT
# ============================================================

class RetrievalAgent:

    def __init__(self):

        # ----------------------------------------------------
        # File paths
        # ----------------------------------------------------

        self.index_path = os.path.join(
            PROJECT_ROOT,
            "rag",
            "support_knowledge.index"
        )

        self.metadata_path = os.path.join(
            PROJECT_ROOT,
            "rag",
            "support_knowledge_metadata.csv"
        )


        # ----------------------------------------------------
        # Check files
        # ----------------------------------------------------

        if not os.path.exists(self.index_path):

            raise FileNotFoundError(
                f"FAISS index not found:\n"
                f"{self.index_path}"
            )

        if not os.path.exists(self.metadata_path):

            raise FileNotFoundError(
                f"Metadata file not found:\n"
                f"{self.metadata_path}"
            )


        # ----------------------------------------------------
        # Load embedding model locally
        #
        # IMPORTANT:
        # Prevents Hugging Face internet connection attempts.
        # ----------------------------------------------------

        self.model = SentenceTransformer(
            "all-MiniLM-L6-v2",
            local_files_only=True
        )


        # ----------------------------------------------------
        # Load FAISS index
        # ----------------------------------------------------

        self.index = faiss.read_index(
            self.index_path
        )


        # ----------------------------------------------------
        # Load metadata
        # ----------------------------------------------------

        self.metadata = pd.read_csv(
            self.metadata_path
        )


        # ----------------------------------------------------
        # Clean column names
        # ----------------------------------------------------

        self.metadata.columns = [
            str(column).strip()
            for column in self.metadata.columns
        ]


        # ----------------------------------------------------
        # Verify metadata/index alignment
        # ----------------------------------------------------

        if len(self.metadata) != self.index.ntotal:

            raise ValueError(
                "FAISS index and metadata size do not match.\n"
                f"FAISS documents: {self.index.ntotal}\n"
                f"Metadata rows: {len(self.metadata)}"
            )


        # ----------------------------------------------------
        # Display loaded information
        # ----------------------------------------------------

        print(
            f"RAG model loaded locally: all-MiniLM-L6-v2"
        )

        print(
            f"FAISS documents loaded: {self.index.ntotal}"
        )

        print(
            f"Metadata columns: "
            f"{self.metadata.columns.tolist()}"
        )


    # ========================================================
    # SAFE COLUMN VALUE
    # ========================================================

    def _get_value(
        self,
        row,
        possible_columns,
        default=""
    ):
        """
        Safely retrieve a value from a metadata row.

        This prevents errors when the metadata schema uses
        different names such as:
            question
            ticket_text
            issue
            answer
            resolution
        """

        for column in possible_columns:

            if column in row.index:

                value = row[column]

                if pd.notna(value):

                    return str(value)

        return default


    # ========================================================
    # BUILD RESULT
    # ========================================================

    def _build_result(
        self,
        row,
        similarity_score
    ):
        """
        Convert one metadata row into the standard
        retrieval-result format used by the rest of
        the project.
        """

        source_type = self._get_value(
            row,
            [
                "source_type",
                "type",
                "source"
            ],
            "UNKNOWN"
        )


        source_id = self._get_value(
            row,
            [
                "source_id",
                "id",
                "faq_id",
                "ticket_id"
            ],
            ""
        )


        category = self._get_value(
            row,
            [
                "category",
                "ticket_category"
            ],
            "Unknown"
        )


        # ----------------------------------------------------
        # Question / issue text
        # ----------------------------------------------------

        issue = self._get_value(
            row,
            [
                "issue",
                "question",
                "ticket_text",
                "text",
                "query"
            ],
            ""
        )


        # ----------------------------------------------------
        # Resolution / answer
        # ----------------------------------------------------

        resolution = self._get_value(
            row,
            [
                "resolution",
                "answer",
                "resolution_text"
            ],
            ""
        )


        # ----------------------------------------------------
        # Return standardized result
        # ----------------------------------------------------

        return {

            "source_type": source_type.upper(),

            "source_id": source_id,

            "category": category,

            "issue": issue,

            "resolution": resolution,

            "similarity_score": round(
                float(similarity_score),
                4
            )
        }


    # ========================================================
    # SEARCH SOURCE
    # ========================================================

    def _search_source(
        self,
        query_embedding,
        source_type,
        top_k=5,
        category=None
    ):
        """
        Search either FAQ or historical ticket documents.

        Category filtering is performed using metadata.
        """

        # ----------------------------------------------------
        # Source filter
        # ----------------------------------------------------

        source_column = None

        if "source_type" in self.metadata.columns:

            source_column = "source_type"

        elif "type" in self.metadata.columns:

            source_column = "type"

        elif "source" in self.metadata.columns:

            source_column = "source"


        if source_column is None:

            raise ValueError(
                "Metadata does not contain a source-type column."
            )


        source_mask = (
            self.metadata[source_column]
            .astype(str)
            .str.upper()
            == source_type.upper()
        )


        source_indices = (
            self.metadata.index[source_mask]
            .tolist()
        )


        # ----------------------------------------------------
        # Category filtering
        # ----------------------------------------------------

        if category and source_indices:

            category_column = None

            if "category" in self.metadata.columns:

                category_column = "category"

            elif "ticket_category" in self.metadata.columns:

                category_column = "ticket_category"


            if category_column:

                requested_category = (
                    str(category)
                    .strip()
                    .lower()
                )


                category_indices = [

                    idx

                    for idx in source_indices

                    if str(
                        self.metadata.iloc[idx][
                            category_column
                        ]
                    ).strip().lower()
                    == requested_category
                ]


                # ------------------------------------------------
                # Use category matches when available.
                # Otherwise fall back to all source documents.
                # ------------------------------------------------

                if category_indices:

                    source_indices = category_indices


        if not source_indices:

            return []


        # ----------------------------------------------------
        # Search FAISS
        # ----------------------------------------------------

        search_k = min(
            max(
                top_k * 20,
                100
            ),
            self.index.ntotal
        )


        distances, indices = self.index.search(
            query_embedding,
            search_k
        )


        # ----------------------------------------------------
        # Collect matching source documents
        # ----------------------------------------------------

        results = []


        valid_indices = set(
            source_indices
        )


        for score, faiss_index in zip(
            distances[0],
            indices[0]
        ):

            if faiss_index < 0:

                continue


            if faiss_index not in valid_indices:

                continue


            row = self.metadata.iloc[
                faiss_index
            ]


            result = self._build_result(
                row,
                score
            )


            results.append(
                result
            )


            if len(results) >= top_k:

                break


        return results


    # ========================================================
    # RETRIEVE
    # ========================================================

    def retrieve(
        self,
        ticket_text,
        category=None,
        top_k=5
    ):
        """
        Retrieve relevant support knowledge.

        Strategy:
            1. Embed ticket.
            2. Search FAQ knowledge base.
            3. Search historical resolved tickets.
            4. Prefer 2 FAQs + 3 historical tickets.
            5. Fill missing results from the best remaining
               candidates.
            6. Sort final results by similarity.
        """

        if not ticket_text or not ticket_text.strip():

            return []


        # ----------------------------------------------------
        # Create embedding
        # ----------------------------------------------------

        query_embedding = self.model.encode(
            [ticket_text.strip()],
            normalize_embeddings=True
        )


        # ----------------------------------------------------
        # Search FAQs
        # ----------------------------------------------------

        faq_results = self._search_source(
            query_embedding,
            "FAQ",
            top_k=10,
            category=category
        )


        # ----------------------------------------------------
        # Search historical resolved tickets
        # ----------------------------------------------------

        ticket_results = self._search_source(
            query_embedding,
            "TICKET",
            top_k=10,
            category=category
        )


        # ----------------------------------------------------
        # Sort independently
        # ----------------------------------------------------

        faq_results = sorted(
            faq_results,
            key=lambda item: item[
                "similarity_score"
            ],
            reverse=True
        )


        ticket_results = sorted(
            ticket_results,
            key=lambda item: item[
                "similarity_score"
            ],
            reverse=True
        )


        # ----------------------------------------------------
        # Balanced retrieval
        #
        # 2 FAQ
        # 3 historical tickets
        # ----------------------------------------------------

        selected_faqs = faq_results[:2]

        selected_tickets = ticket_results[:3]


        combined = (
            selected_faqs
            + selected_tickets
        )


        # ----------------------------------------------------
        # If one source has fewer results, fill remaining
        # positions using highest similarity.
        # ----------------------------------------------------

        if len(combined) < top_k:

            all_candidates = (
                faq_results
                + ticket_results
            )


            existing = {

                (
                    item["source_type"],
                    item["source_id"]
                )

                for item in combined
            }


            remaining = [

                item

                for item in all_candidates

                if (
                    item["source_type"],
                    item["source_id"]
                )
                not in existing
            ]


            remaining = sorted(
                remaining,
                key=lambda item: item[
                    "similarity_score"
                ],
                reverse=True
            )


            needed = (
                top_k
                - len(combined)
            )


            combined.extend(
                remaining[:needed]
            )


        # ----------------------------------------------------
        # Final ranking
        # ----------------------------------------------------

        combined = sorted(
            combined,
            key=lambda item: item[
                "similarity_score"
            ],
            reverse=True
        )


        return combined[:top_k]


# ============================================================
# DIRECT TEST
# ============================================================

if __name__ == "__main__":

    print("\n" + "=" * 60)
    print("RETRIEVAL AGENT TEST")
    print("=" * 60)


    # --------------------------------------------------------
    # Initialize
    # --------------------------------------------------------

    agent = RetrievalAgent()


    # --------------------------------------------------------
    # Test query
    # --------------------------------------------------------

    test_query = (
        "Can I get a replacement for my defective "
        "wireless headphones?"
    )


    print("\nQuery:")
    print(test_query)


    # --------------------------------------------------------
    # Retrieve
    # --------------------------------------------------------

    results = agent.retrieve(
        test_query,
        category="Product Issue",
        top_k=5
    )


    # --------------------------------------------------------
    # Display results
    # --------------------------------------------------------

    print("\n" + "-" * 60)
    print("RETRIEVED RESULTS")
    print("-" * 60)


    if not results:

        print("No results found.")


    else:

        for number, result in enumerate(
            results,
            start=1
        ):

            print(
                f"\n{number}. "
                f"{result['source_type']} | "
                f"{result['source_id']} | "
                f"{result['category']} | "
                f"{result['similarity_score']}"
            )


            if result["source_type"] == "FAQ":

                print(
                    f"   Question: "
                    f"{result['issue']}"
                )

            else:

                print(
                    f"   Issue: "
                    f"{result['issue']}"
                )


            print(
                f"   Resolution: "
                f"{result['resolution']}"
            )


    # --------------------------------------------------------
    # Statistics
    # --------------------------------------------------------

    faq_count = sum(

        1

        for result in results

        if result["source_type"] == "FAQ"
    )


    ticket_count = sum(

        1

        for result in results

        if result["source_type"] == "TICKET"
    )


    print("\n" + "-" * 60)

    print(
        f"FAQ results: {faq_count}"
    )

    print(
        f"Historical ticket results: "
        f"{ticket_count}"
    )

    print(
        f"Total results: {len(results)}"
    )

    print("-" * 60)


    print(
        "\nRetrieval test completed successfully."
    )