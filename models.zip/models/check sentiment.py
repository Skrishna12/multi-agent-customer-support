import pandas as pd

df = pd.read_csv("data/support_tickets_10k.csv")

for sentiment in df["sentiment"].unique():

    print("\n" + "=" * 60)
    print("SENTIMENT:", sentiment)
    print("=" * 60)

    samples = df[df["sentiment"] == sentiment]["ticket_text"].head(5)

    for i, text in enumerate(samples, 1):
        print(f"\n{i}. {text}")