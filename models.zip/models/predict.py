import joblib


# Load trained models
category_model = joblib.load("models/category_model.pkl")
priority_model = joblib.load("models/priority_model.pkl")


def predict_ticket(ticket_text):

    # -------------------------
    # Category prediction
    # -------------------------

    category = category_model.predict([ticket_text])[0]

    category_probabilities = category_model.predict_proba(
        [ticket_text]
    )[0]

    category_confidence = max(category_probabilities)


    # -------------------------
    # Priority prediction
    # -------------------------

    priority = priority_model.predict([ticket_text])[0]

    priority_probabilities = priority_model.predict_proba(
        [ticket_text]
    )[0]

    priority_confidence = max(priority_probabilities)


    # -------------------------
    # Return results
    # -------------------------

    return {
        "category": category,
        "category_confidence": round(category_confidence * 100, 2),
        "priority": priority,
        "priority_confidence": round(priority_confidence * 100, 2)
    }


# Test the model
if __name__ == "__main__":

    ticket = input("\nEnter customer ticket: ")

    result = predict_ticket(ticket)

    print("\n===== PREDICTION =====")

    print("Category:", result["category"])
    print(
        "Category Confidence:",
        str(result["category_confidence"]) + "%"
    )

    print("Priority:", result["priority"])
    print(
        "Priority Confidence:",
        str(result["priority_confidence"]) + "%"
    )