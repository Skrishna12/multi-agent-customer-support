import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, accuracy_score

import joblib


# ==========================================
# 1. LOAD DATA
# ==========================================

df = pd.read_csv("data/support_tickets_10k.csv")

print("Dataset loaded:", df.shape)


# ==========================================
# 2. PREPARE DATA
# ==========================================

X = df["ticket_text"]

y_category = df["ticket_category"]
y_priority = df["priority"]


# ==========================================
# 3. TRAIN-TEST SPLIT
# ==========================================

X_train, X_test, y_category_train, y_category_test = train_test_split(
    X,
    y_category,
    test_size=0.2,
    random_state=42,
    stratify=y_category
)

print("\nTraining samples:", len(X_train))
print("Testing samples:", len(X_test))


# ==========================================
# 4. CATEGORY MODEL
# ==========================================

category_model = Pipeline([
    (
        "tfidf",
        TfidfVectorizer(
            lowercase=True,
            stop_words="english",
            ngram_range=(1, 2),
            max_features=10000
        )
    ),
    (
        "classifier",
        LogisticRegression(
            max_iter=1000
        )
    )
])


print("\nTraining category model...")

category_model.fit(
    X_train,
    y_category_train
)


# ==========================================
# 5. CATEGORY EVALUATION
# ==========================================

category_predictions = category_model.predict(X_test)

category_accuracy = accuracy_score(
    y_category_test,
    category_predictions
)

print("\n===== CATEGORY MODEL =====")
print("Accuracy:", round(category_accuracy, 4))

print("\nClassification Report:")
print(
    classification_report(
        y_category_test,
        category_predictions
    )
)


# ==========================================
# 6. PRIORITY MODEL
# ==========================================

X_train_p, X_test_p, y_priority_train, y_priority_test = train_test_split(
    X,
    y_priority,
    test_size=0.2,
    random_state=42,
    stratify=y_priority
)


priority_model = Pipeline([
    (
        "tfidf",
        TfidfVectorizer(
            lowercase=True,
            stop_words="english",
            ngram_range=(1, 2),
            max_features=10000
        )
    ),
    (
        "classifier",
        LogisticRegression(
            max_iter=1000
        )
    )
])


print("\nTraining priority model...")

priority_model.fit(
    X_train_p,
    y_priority_train
)


# ==========================================
# 7. PRIORITY EVALUATION
# ==========================================

priority_predictions = priority_model.predict(X_test_p)

priority_accuracy = accuracy_score(
    y_priority_test,
    priority_predictions
)

print("\n===== PRIORITY MODEL =====")
print("Accuracy:", round(priority_accuracy, 4))

print("\nClassification Report:")
print(
    classification_report(
        y_priority_test,
        priority_predictions
    )
)

# ==========================================
# 8. SENTIMENT MODEL
# ==========================================

X_train_s, X_test_s, y_sentiment_train, y_sentiment_test = train_test_split(
    X,
    df["sentiment"],
    test_size=0.2,
    random_state=42,
    stratify=df["sentiment"]
)


sentiment_model = Pipeline([
    (
        "tfidf",
        TfidfVectorizer(
            lowercase=True,
            stop_words="english",
            ngram_range=(1, 2),
            max_features=10000
        )
    ),
    (
        "classifier",
        LogisticRegression(
            max_iter=1000
        )
    )
])


print("\nTraining sentiment model...")

sentiment_model.fit(
    X_train_s,
    y_sentiment_train
)


# ==========================================
# 8. SENTIMENT EVALUATION
# ==========================================

sentiment_predictions = sentiment_model.predict(X_test_s)

sentiment_accuracy = accuracy_score(
    y_sentiment_test,
    sentiment_predictions
)

print("\n===== SENTIMENT MODEL =====")
print("Accuracy:", round(sentiment_accuracy, 4))

print("\nClassification Report:")
print(
    classification_report(
        y_sentiment_test,
        sentiment_predictions
    )
)


# ==========================================
# 9. SAVE SENTIMENT MODEL
# ==========================================

joblib.dump(
    sentiment_model,
    "models/sentiment_model.pkl"
)

print("\nSentiment model saved!")

# ==========================================
# 10. SAVE MODELS
# ==========================================

joblib.dump(
    category_model,
    "models/category_model.pkl"
)

joblib.dump(
    priority_model,
    "models/priority_model.pkl"
)


print("\nModels saved successfully!")

print("models/category_model.pkl")
print("models/priority_model.pkl")