import sys
import os
import sqlite3


# Add project root to Python path
sys.path.append(
    os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))
    )
)


DATABASE_FILE = "database/support_system.db"


class LearningAgent:

    def __init__(self, database_file=DATABASE_FILE):
        self.database_file = database_file

    def get_connection(self):
        return sqlite3.connect(self.database_file)

    # =========================================================
    # GET BASIC TICKET STATISTICS
    # =========================================================

    def get_ticket_statistics(self):

        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT COUNT(*)
            FROM tickets
        """)

        total_tickets = cursor.fetchone()[0]

        cursor.execute("""
            SELECT COUNT(*)
            FROM tickets
            WHERE escalation_decision = 'AUTO-HANDLE'
        """)

        auto_handled = cursor.fetchone()[0]

        cursor.execute("""
            SELECT COUNT(*)
            FROM tickets
            WHERE escalation_decision = 'ESCALATE'
        """)

        escalated = cursor.fetchone()[0]

        conn.close()

        return {
            "total_tickets": total_tickets,
            "auto_handled": auto_handled,
            "escalated": escalated
        }

    # =========================================================
    # GET CATEGORY STATISTICS
    # =========================================================

    def get_category_statistics(self):

        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                category,
                COUNT(*) AS ticket_count
            FROM tickets
            GROUP BY category
            ORDER BY ticket_count DESC
        """)

        results = cursor.fetchall()

        conn.close()

        return results

    # =========================================================
    # GET SENTIMENT STATISTICS
    # =========================================================

    def get_sentiment_statistics(self):

        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                sentiment,
                COUNT(*) AS ticket_count
            FROM tickets
            GROUP BY sentiment
            ORDER BY ticket_count DESC
        """)

        results = cursor.fetchall()

        conn.close()

        return results

    # =========================================================
    # GET AVERAGE CONFIDENCE
    # =========================================================

    def get_average_confidence(self):

        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                AVG(category_confidence),
                AVG(priority_confidence),
                AVG(sentiment_confidence)
            FROM tickets
        """)

        result = cursor.fetchone()

        conn.close()

        return {
            "category_confidence": result[0],
            "priority_confidence": result[1],
            "sentiment_confidence": result[2]
        }

    # =========================================================
    # GET RETRIEVAL QUALITY
    # =========================================================

    def get_retrieval_statistics(self):

        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                COUNT(*),
                AVG(similarity_score)
            FROM retrieval_logs
        """)

        result = cursor.fetchone()

        conn.close()

        return {
            "retrieval_results": result[0],
            "average_similarity": result[1]
        }

    # =========================================================
    # GET FEEDBACK STATISTICS
    # =========================================================

    def get_feedback_statistics(self):

        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                COUNT(*),
                AVG(helpful),
                AVG(resolved),
                AVG(customer_satisfaction)
            FROM feedback
        """)

        result = cursor.fetchone()

        conn.close()

        return {
            "feedback_count": result[0],
            "helpful_rate": result[1],
            "resolution_rate": result[2],
            "average_satisfaction": result[3]
        }

    # =========================================================
    # GENERATE LEARNING REPORT
    # =========================================================

    def generate_learning_report(self):

        ticket_stats = self.get_ticket_statistics()

        category_stats = self.get_category_statistics()

        sentiment_stats = self.get_sentiment_statistics()

        confidence_stats = self.get_average_confidence()

        retrieval_stats = self.get_retrieval_statistics()

        feedback_stats = self.get_feedback_statistics()

        total = ticket_stats["total_tickets"]

        if total > 0:

            automation_rate = (
                ticket_stats["auto_handled"]
                / total
            ) * 100

            escalation_rate = (
                ticket_stats["escalated"]
                / total
            ) * 100

        else:

            automation_rate = 0
            escalation_rate = 0

        return {

            "ticket_statistics": ticket_stats,

            "automation_rate":
                round(automation_rate, 2),

            "escalation_rate":
                round(escalation_rate, 2),

            "category_statistics":
                category_stats,

            "sentiment_statistics":
                sentiment_stats,

            "confidence_statistics":
                confidence_stats,

            "retrieval_statistics":
                retrieval_stats,

            "feedback_statistics":
                feedback_stats
        }


# =============================================================
# TEST LEARNING AGENT
# =============================================================

if __name__ == "__main__":

    agent = LearningAgent()

    report = agent.generate_learning_report()

    print("\n" + "=" * 60)
    print("LEARNING AGENT")
    print("=" * 60)

    # ---------------------------------------------------------
    # Ticket statistics
    # ---------------------------------------------------------

    print("\n📊 TICKET STATISTICS")

    print(
        "Total Tickets:",
        report["ticket_statistics"]["total_tickets"]
    )

    print(
        "Auto-Handled:",
        report["ticket_statistics"]["auto_handled"]
    )

    print(
        "Escalated:",
        report["ticket_statistics"]["escalated"]
    )

    print(
        "Automation Rate:",
        str(report["automation_rate"]) + "%"
    )

    print(
        "Escalation Rate:",
        str(report["escalation_rate"]) + "%"
    )

    # ---------------------------------------------------------
    # Category statistics
    # ---------------------------------------------------------

    print("\n📂 CATEGORY STATISTICS")

    for category, count in report["category_statistics"]:

        print(
            f"{category}: {count}"
        )

    # ---------------------------------------------------------
    # Sentiment statistics
    # ---------------------------------------------------------

    print("\n💬 SENTIMENT STATISTICS")

    for sentiment, count in report["sentiment_statistics"]:

        print(
            f"{sentiment}: {count}"
        )

    # ---------------------------------------------------------
    # Confidence
    # ---------------------------------------------------------

    print("\n🎯 AVERAGE CONFIDENCE")

    print(
        "Category:",
        round(
            report["confidence_statistics"]
            ["category_confidence"],
            2
        ) if report["confidence_statistics"]
        ["category_confidence"] is not None
        else 0,
        "%"
    )

    print(
        "Priority:",
        round(
            report["confidence_statistics"]
            ["priority_confidence"],
            2
        ) if report["confidence_statistics"]
        ["priority_confidence"] is not None
        else 0,
        "%"
    )

    print(
        "Sentiment:",
        round(
            report["confidence_statistics"]
            ["sentiment_confidence"],
            2
        ) if report["confidence_statistics"]
        ["sentiment_confidence"] is not None
        else 0,
        "%"
    )

    # ---------------------------------------------------------
    # Retrieval
    # ---------------------------------------------------------

    print("\n🔎 RETRIEVAL STATISTICS")

    print(
        "Retrieval Results:",
        report["retrieval_statistics"]
        ["retrieval_results"]
    )

    print(
        "Average Similarity:",
        round(
            report["retrieval_statistics"]
            ["average_similarity"],
            4
        ) if report["retrieval_statistics"]
        ["average_similarity"] is not None
        else 0
    )

    # ---------------------------------------------------------
    # Feedback
    # ---------------------------------------------------------

    print("\n⭐ FEEDBACK STATISTICS")

    print(
        "Feedback Records:",
        report["feedback_statistics"]
        ["feedback_count"]
    )

    if report["feedback_statistics"]["feedback_count"] > 0:

        print(
            "Helpful Rate:",
            round(
                report["feedback_statistics"]
                ["helpful_rate"] * 100,
                2
            ),
            "%"
        )

        print(
            "Resolution Rate:",
            round(
                report["feedback_statistics"]
                ["resolution_rate"] * 100,
                2
            ),
            "%"
        )

        print(
            "Average Satisfaction:",
            round(
                report["feedback_statistics"]
                ["average_satisfaction"],
                2
            )
        )

    else:

        print("No customer feedback recorded yet.")

    print("\n" + "=" * 60)