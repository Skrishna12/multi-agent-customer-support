import sys
import os

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

if PROJECT_ROOT not in sys.path:
    sys.path.append(PROJECT_ROOT)

import joblib


class ClassificationAgent:
    """
    Conversation-aware Classification Agent.

    Responsibilities:
    - Predict ticket category using ML
    - Predict priority using ML
    - Apply rule-based corrections for important product/delivery cases
    - Preserve original category and priority for follow-up messages
    """

    CATEGORY_MODEL_PATH = "models/category_model.pkl"
    PRIORITY_MODEL_PATH = "models/priority_model.pkl"

    TEAM_MAPPING = {
        "Delivery Issue": "Logistics & Delivery Team",
        "Refund & Return": "Returns & Refunds Team",
        "Payment Issue": "Payments Team",
        "Product Issue": "Product Support Team",
        "Account & Login": "Account & Security Team",
        "Seller & Product Listing": "Seller Operations Team",
        "App & Website Issue": "Technical Support Team",
    }

    CATEGORY_KEYWORDS = {
        "Delivery Issue": [
            "delivery",
            "delivered",
            "shipment",
            "tracking",
            "track",
            "package",
            "arrive",
            "arrived",
            "not received",
            "haven't received",
            "hasn't arrived",
            "didn't arrive",
            "delayed",
            "delay",
            "late",
            "out for delivery",
            "in transit",
        ],
        "Refund & Return": [
            "refund",
            "return",
            "money back",
            "reimburse",
            "reimbursement",
        ],
        "Payment Issue": [
            "payment",
            "charged",
            "charge",
            "transaction",
            "card",
            "duplicate payment",
            "charged twice",
            "double charged",
            "payment failed",
        ],
        "Product Issue": [
            "damaged",
            "broken",
            "defective",
            "faulty",
            "cracked",
            "not working",
            "doesn't work",
            "does not work",
            "malfunction",
            "wrong product",
            "wrong item",
            "different product",
            "missing parts",
            "missing item",
            "replacement",
            "expired",
        ],
        "Account & Login": [
            "account",
            "login",
            "log in",
            "password",
            "locked",
            "sign in",
            "access account",
        ],
        "Seller & Product Listing": [
            "seller",
            "listing",
            "merchant",
            "product listing",
        ],
        "App & Website Issue": [
            "website",
            "app",
            "application",
            "page not loading",
            "error on website",
            "error on app",
            "crashed",
        ],
    }

    PRODUCT_PROBLEM_PHRASES = [
        "not working",
        "doesn't work",
        "does not work",
        "malfunction",
        "defective",
        "damaged",
        "broken",
        "cracked",
        "faulty",
        "wrong product",
        "wrong item",
        "different product",
        "replacement",
        "expired",
        "missing parts",
    ]

    def __init__(self):
        self.category_model = joblib.load(
            self.CATEGORY_MODEL_PATH
        )

        self.priority_model = joblib.load(
            self.PRIORITY_MODEL_PATH
        )

    def _calculate_keyword_scores(self, text):
        """
        Calculate rule-based category scores.
        """
        text_lower = text.lower()

        scores = {}

        for category, keywords in self.CATEGORY_KEYWORDS.items():
            score = 0

            for keyword in keywords:
                if keyword in text_lower:
                    score += 1

            scores[category] = score

        return scores

    def _get_rule_category(self, text):
        """
        Determine category using high-value rules.
        """
        scores = self._calculate_keyword_scores(text)

        text_lower = text.lower()

        # Product problems are highly important and should
        # override generic delivery/payment words when the
        # customer is clearly reporting a product problem.
        has_product_problem = any(
            phrase in text_lower
            for phrase in self.PRODUCT_PROBLEM_PHRASES
        )

        if has_product_problem:
            product_score = scores.get("Product Issue", 0)

            return (
                "Product Issue",
                min(85 + product_score * 2, 95),
                product_score
            )

        # Compare delivery and product signals.
        delivery_score = scores.get("Delivery Issue", 0)
        product_score = scores.get("Product Issue", 0)

        if product_score > delivery_score and product_score > 0:
            return (
                "Product Issue",
                min(80 + product_score * 3, 95),
                product_score
            )

        if delivery_score > 0:
            return (
                "Delivery Issue",
                min(80 + delivery_score * 3, 95),
                delivery_score
            )

        # Refund/return signals.
        refund_score = scores.get("Refund & Return", 0)

        if refund_score > 0:
            return (
                "Refund & Return",
                min(80 + refund_score * 3, 95),
                refund_score
            )

        return None, 0, 0

    def _predict_ml_category(self, text):
        """
        ML category prediction.
        """
        category = self.category_model.predict([text])[0]

        probabilities = self.category_model.predict_proba([text])[0]

        confidence = max(probabilities) * 100

        return category, round(confidence, 2)

    def _predict_ml_priority(self, text):
        """
        ML priority prediction.
        """
        priority = self.priority_model.predict([text])[0]

        probabilities = self.priority_model.predict_proba([text])[0]

        confidence = max(probabilities) * 100

        return priority, round(confidence, 2)

    def _classify_new_ticket(self, text):
        """
        Normal classification for a brand-new ticket.
        """

        ml_category, ml_confidence = self._predict_ml_category(text)

        rule_category, rule_confidence, rule_score = (
            self._get_rule_category(text)
        )

        # Prefer strong product rules.
        if rule_category == "Product Issue":
            final_category = rule_category
            final_confidence = rule_confidence

        # Prefer strong delivery rules.
        elif rule_category == "Delivery Issue":
            final_category = rule_category
            final_confidence = rule_confidence

        # Otherwise use ML.
        elif rule_category is not None:
            final_category = rule_category
            final_confidence = rule_confidence

        else:
            final_category = ml_category
            final_confidence = ml_confidence

        priority, priority_confidence = (
            self._predict_ml_priority(text)
        )

        return {
            "category": final_category,
            "category_confidence": round(
                final_confidence,
                2
            ),
            "priority": priority,
            "priority_confidence": round(
                priority_confidence,
                2
            ),
            "ml_category": ml_category,
            "ml_category_confidence": ml_confidence,
            "rule_category": rule_category,
            "rule_score": rule_score,
            "assigned_team": self.TEAM_MAPPING.get(
                final_category,
                "General Support Team"
            ),
            "is_follow_up": False,
        }

    def _classify_follow_up(
        self,
        text,
        previous_context
    ):
        """
        Classification for a follow-up message.

        The original category and priority are preserved.
        Only the customer's new request/intent is allowed to change.
        """

        previous_category = previous_context.get(
            "category",
            "General Inquiry"
        )

        previous_priority = previous_context.get(
            "priority",
            "Medium"
        )

        previous_category_confidence = previous_context.get(
            "category_confidence",
            80
        )

        previous_priority_confidence = previous_context.get(
            "priority_confidence",
            80
        )

        # If the previous context already has ML/rule information,
        # preserve it for transparency.
        previous_ml_category = previous_context.get(
            "ml_category",
            previous_category
        )

        previous_ml_confidence = previous_context.get(
            "ml_category_confidence",
            previous_category_confidence
        )

        previous_rule_category = previous_context.get(
            "rule_category",
            previous_category
        )

        previous_rule_score = previous_context.get(
            "rule_score",
            0
        )

        return {
            "category": previous_category,
            "category_confidence": round(
                previous_category_confidence,
                2
            ),
            "priority": previous_priority,
            "priority_confidence": round(
                previous_priority_confidence,
                2
            ),
            "ml_category": previous_ml_category,
            "ml_category_confidence": round(
                previous_ml_confidence,
                2
            ),
            "rule_category": previous_rule_category,
            "rule_score": previous_rule_score,
            "assigned_team": self.TEAM_MAPPING.get(
                previous_category,
                "General Support Team"
            ),
            "is_follow_up": True,
        }

    def classify(
        self,
        ticket_text,
        previous_context=None
    ):
        """
        Main classification method.

        If previous_context exists, treat the message as a
        follow-up and preserve the original classification.
        """

        if not ticket_text or not ticket_text.strip():
            raise ValueError(
                "Ticket text cannot be empty."
            )

        previous_context = previous_context or {}

        text = ticket_text.strip()

        if previous_context:
            return self._classify_follow_up(
                text,
                previous_context
            )

        return self._classify_new_ticket(text)

    def process(
        self,
        ticket_text,
        previous_context=None
    ):
        """
        Alias used by the support pipeline.
        """
        return self.classify(
            ticket_text,
            previous_context
        )


if __name__ == "__main__":

    agent = ClassificationAgent()

    original_ticket = (
        "Order #ORD7824512 was supposed to arrive 3 days ago "
        "but the tracking hasn't updated. I was also charged twice "
        "for my wireless headphones. I'm extremely frustrated and "
        "I want a refund immediately."
    )

    print("\n" + "=" * 60)
    print("INITIAL TICKET")
    print("=" * 60)

    first_result = agent.process(
        original_ticket
    )

    for key, value in first_result.items():
        print(f"{key}: {value}")

    follow_up = (
        "Can I get a replacement instead of a refund?"
    )

    print("\n" + "=" * 60)
    print("FOLLOW-UP TICKET")
    print("=" * 60)

    second_result = agent.process(
        follow_up,
        previous_context=first_result
    )

    for key, value in second_result.items():
        print(f"{key}: {value}")