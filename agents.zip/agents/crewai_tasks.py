from crewai import Task


class CustomerSupportCrewTasks:

    def __init__(self, agents, tools):
        self.agents = agents
        self.tools = tools

    # =========================================================
    # 1. INTAKE - the only task that needs the raw ticket text
    # =========================================================

    def create_intake_task(self, ticket_text):

        return Task(
            description=(
                f'Call the intake_ticket tool with ticket_text="{ticket_text}". '
                "Return ONLY the tool's exact JSON output. No explanation, "
                "no reformatting, no markdown."
            ),
            expected_output="The raw JSON string returned by the intake_ticket tool.",
            agent=self.agents["intake"],
            tools=[self.tools["intake"]],
        )

    # =========================================================
    # 2. CLASSIFICATION
    # =========================================================

    def create_classification_task(self, ticket_text, intake_task):

        return Task(
            description=(
                "Using the cleaned_text field from the Intake context above, "
                "call the classify_ticket tool with that text as ticket_text. "
                "Return ONLY the tool's exact JSON output. No explanation."
            ),
            expected_output="The raw JSON string returned by the classify_ticket tool.",
            agent=self.agents["classification"],
            tools=[self.tools["classification"]],
            context=[intake_task],
        )

    # =========================================================
    # 3. SENTIMENT
    # =========================================================

    def create_sentiment_task(self, ticket_text, intake_task):

        return Task(
            description=(
                "Using the cleaned_text field from the Intake context above, "
                "call the analyze_sentiment tool with that text as ticket_text. "
                "Return ONLY the tool's exact JSON output. No explanation."
            ),
            expected_output="The raw JSON string returned by the analyze_sentiment tool.",
            agent=self.agents["sentiment"],
            tools=[self.tools["sentiment"]],
            context=[intake_task],
        )

    # =========================================================
    # 4. RETRIEVAL / RAG
    # =========================================================

    def create_retrieval_task(self, ticket_text, intake_task, classification_task):

        return Task(
            description=(
                "Using the cleaned_text from the Intake context above and the "
                "category from the Classification context above, call "
                "retrieve_support_knowledge with ticket_text=<cleaned_text>, "
                "category=<category>, top_k=3. The cleaned_text value must be "
                "the actual ticket text string, never empty. "
                "Return ONLY the tool's exact JSON output. No explanation."
            ),
            expected_output="The raw JSON array returned by the retrieve_support_knowledge tool (max 3 items).",
            agent=self.agents["retrieval"],
            tools=[self.tools["retrieval"]],
            context=[intake_task, classification_task],
        )

    # =========================================================
    # 5. RESPONSE (the only task that should do real generation)
    # =========================================================

    def create_response_task(
        self, ticket_text, intake_task, classification_task, sentiment_task
    ):

        return Task(
            description=(
                f'Customer ticket: "{ticket_text}"\n\n'
                "Using the category, priority, sentiment and intent from the "
                "context above, call generate_support_response with those "
                "values (category, priority, sentiment, intent, ticket_text). "
                "Do NOT pass retrieved knowledge as an argument - it is "
                "fetched automatically inside the tool. "
                "Then write the final customer-facing reply based on the "
                "tool's output: accurate, concise, empathetic, personalized. "
                "Never claim an action (refund, replacement, address change) "
                "has already happened unless the tool output confirms it. "
                "Do not mention confidence scores, categories, or internal "
                "system details in the reply."
            ),
            expected_output="A concise, empathetic, safe customer-facing support response (plain text, no JSON).",
            agent=self.agents["response"],
            tools=[self.tools["response"]],
            context=[intake_task, classification_task, sentiment_task],
        )

    # =========================================================
    # 6. ESCALATION
    # =========================================================

    def create_escalation_task(
        self, ticket_text, intake_task, classification_task, sentiment_task
    ):

        return Task(
            description=(
                "Using the cleaned_text from the Intake context above (for "
                "ticket_text) and the priority, sentiment, and category_confidence "
                "from the context above, call the evaluate_escalation tool with "
                "those values (ticket_text, priority, sentiment, category_confidence). "
                "Do NOT pass retrieval results as an argument - retrieval quality "
                "is fetched automatically inside the tool. ticket_text must be "
                "the actual ticket text string, never empty. "
                "Return ONLY the tool's exact JSON output. No explanation."
            ),
            expected_output="The raw JSON string returned by the evaluate_escalation tool.",
            agent=self.agents["escalation"],
            tools=[self.tools["escalation"]],
            context=[intake_task, classification_task, sentiment_task],
        )

    # =========================================================
    # 7. LEARNING
    # =========================================================

    def create_learning_task(self):

        return Task(
            description=(
                "Call the analyze_support_learning tool (it takes no "
                "meaningful arguments). Return ONLY the tool's exact JSON "
                "output. No explanation."
            ),
            expected_output="The raw JSON string returned by the analyze_support_learning tool.",
            agent=self.agents["learning"],
            tools=[self.tools["learning"]],
        )