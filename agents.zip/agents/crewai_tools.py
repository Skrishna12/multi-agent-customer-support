"""
CrewAI tools for the Multi-Agent Customer Support Intelligence Platform.

These tools wrap the deterministic/ML/RAG components so CrewAI agents
can execute the actual customer-support workflow. Tool outputs are kept
as compact JSON to minimize tokens carried forward into later tasks.
"""

from typing import Optional, Any
import json

from pydantic import BaseModel, Field
from crewai.tools import BaseTool

from agents.intake_agent import IntakeAgent
from agents.classification_agent import ClassificationAgent
from agents.sentiment_agent import SentimentAgent
from rag.retrieval_agent import RetrievalAgent
from agents.response_agent import ResponseAgent
from agents.escalation_agent import EscalationAgent
from agents.learning_agent import LearningAgent


# ============================================================
# SHARED COMPONENTS (single instances - do not re-instantiate
# these elsewhere, e.g. in the orchestrator, or the FAISS index
# and models get loaded twice)
# ============================================================

_intake = IntakeAgent()
_classification = ClassificationAgent()
_sentiment = SentimentAgent()
_retrieval = RetrievalAgent()
_response = ResponseAgent()
_escalation = EscalationAgent()
_learning = LearningAgent()

# Holds the most recent retrieval results within a single pipeline run.
# Response/Escalation tools read from here instead of requiring the LLM to
# retype the full retrieval JSON array as a function-call argument - asking
# a model to transcribe a large array verbatim as tool-call arguments is
# exactly what caused the "Failed to parse tool call arguments as JSON"
# truncation error. NOTE: this is a simple module-level cache, correct for
# one ticket processed at a time. If you later call process_ticket()
# concurrently for multiple tickets in the same process (e.g. from FastAPI
# under load), this would need to become per-request/ticket-id scoped
# instead of a single shared dict.
_pipeline_cache = {"retrieval_results": []}

# Holds the ground-truth ticket text and previous_context for the ticket
# currently being processed, set by the orchestrator before crew.kickoff().
# IntakeTool reads from here instead of trusting whatever the LLM retyped
# into its tool-call arguments - this guarantees the order ID / product
# regex extraction always runs against the real, unmodified text, and lets
# IntakeAgent's own previous_context entity-carryover logic actually run
# (which crewai_tools.py previously never passed through at all).
_request_context = {"ticket_text": "", "previous_context": None}


def set_request_context(ticket_text: str, previous_context: Optional[dict] = None):
    _request_context["ticket_text"] = ticket_text
    _request_context["previous_context"] = previous_context


# ============================================================
# INTAKE TOOL
# ============================================================

class IntakeTool(BaseTool):
    name: str = "intake_ticket"
    description: str = (
        "Clean and analyze a customer support ticket. "
        "Extract customer intent, urgency, order ID and product."
    )

    def _run(self, ticket_text: str) -> str:
        # Use the ground-truth text set by the orchestrator, not the LLM's
        # retyped copy - see _request_context comment above for why.
        real_ticket_text = _request_context.get("ticket_text") or ticket_text
        previous_context = _request_context.get("previous_context")

        result = _intake.process(real_ticket_text, previous_context=previous_context)

        compact = {
            "cleaned_text": result.get("cleaned_text", real_ticket_text),
            "customer_intent": result.get("customer_intent") or result.get("intent"),
            "urgency": result.get("urgency"),
            "entities": result.get("entities"),
        }

        return json.dumps(compact, ensure_ascii=False)


# ============================================================
# CLASSIFICATION TOOL
# ============================================================

class ClassificationTool(BaseTool):
    name: str = "classify_ticket"
    description: str = (
        "Classify a customer support ticket into the correct category "
        "and priority and assign the appropriate support team."
    )

    def _run(self, ticket_text: str) -> str:
        result = _classification.process(ticket_text)

        compact = {
            "category": result.get("category"),
            "category_confidence": float(result.get("category_confidence", 0)),
            "priority": result.get("priority"),
            "priority_confidence": float(result.get("priority_confidence", 0)),
            "assigned_team": result.get(
                "assigned_team",
                result.get("support_team")
            ),
        }

        return json.dumps(compact, ensure_ascii=False)


# ============================================================
# SENTIMENT TOOL
# ============================================================

class SentimentTool(BaseTool):
    name: str = "analyze_sentiment"
    description: str = (
        "Analyze customer sentiment using the project's sentiment "
        "analysis logic and return sentiment, confidence and signals."
    )

    def _run(self, ticket_text: str) -> str:
        result = _sentiment.analyze(ticket_text)

        compact = {
            "sentiment": result.get("sentiment"),
            "confidence": float(result.get("confidence", 0)),
            "negative_signals": result.get("negative_signals", 0),
            "very_negative_signals": result.get("very_negative_signals", 0),
            "positive_signals": result.get("positive_signals", 0),
        }

        return json.dumps(compact, ensure_ascii=False)


# ============================================================
# RETRIEVAL TOOL
# ============================================================

class RetrievalTool(BaseTool):
    name: str = "retrieve_support_knowledge"
    description: str = (
        "Retrieve relevant FAQ and historically resolved customer "
        "support tickets using the FAISS RAG knowledge base. "
        "Category is optional."
    )

    def _run(
        self,
        ticket_text: str,
        category: Optional[str] = None,
        top_k: int = 3,
    ) -> str:

        # Cap at 3 regardless of what's requested - the Response Agent
        # only needs a handful of grounding examples, not five.
        top_k = min(top_k, 3)

        results = _retrieval.retrieve(
            ticket_text=ticket_text,
            category=category,
            top_k=top_k
        )

        compact_results = []

        for result in results[:top_k]:

            issue = result.get("issue", result.get("text", ""))
            resolution = result.get("resolution", "")

            if issue:
                issue = str(issue).replace("Customer Issue:", "").strip()

            if resolution:
                resolution = str(resolution).replace("Resolution:", "").strip()

            compact_results.append({
                "source_type": result.get("source_type", "TICKET"),
                "source_id": result.get("source_id", result.get("id")),
                "category": result.get("category"),
                "issue": issue[:220],
                "resolution": resolution[:220],
                "similarity": round(
                    float(result.get("similarity_score", result.get("similarity", 0))),
                    4
                ),
            })

        _pipeline_cache["retrieval_results"] = compact_results
        return json.dumps(compact_results, ensure_ascii=False)


# ============================================================
# RESPONSE TOOL
# ============================================================

class ResponseTool(BaseTool):
    name: str = "generate_support_response"
    description: str = (
        "Generate an empathetic, concise and personalized customer "
        "support response using classification, sentiment and RAG knowledge. "
        "Retrieved knowledge is fetched automatically - do not pass it."
    )

    def _run(
        self,
        ticket_text: str,
        category: str,
        priority: str,
        sentiment: str,
        intent: Optional[str] = None
    ) -> str:

        # Retrieved knowledge comes from the internal cache (set by the
        # most recent retrieve_support_knowledge call), not from the LLM -
        # see _pipeline_cache comment above for why.
        retrieved_results = _pipeline_cache.get("retrieval_results", [])

        result = _response.generate_response(
            ticket=ticket_text,
            category=category,
            priority=priority,
            sentiment=sentiment,
            retrieved_results=retrieved_results,
            intent=intent
        )

        if isinstance(result, dict):
            return str(result.get("response", result.get("text", "")))

        return str(result)


# ============================================================
# ESCALATION TOOL
# ============================================================

class EscalationTool(BaseTool):
    name: str = "evaluate_escalation"
    description: str = (
        "Evaluate whether a customer support ticket should be "
        "AUTO-HANDLE or ESCALATE using priority, sentiment, "
        "classification confidence and retrieval quality. "
        "Retrieval quality is fetched automatically - do not pass it."
    )

    def _run(
        self,
        ticket_text: str,
        priority: str,
        sentiment: str,
        category_confidence: float,
    ) -> str:

        # Same reasoning as ResponseTool: read retrieval results from the
        # internal cache instead of requiring the LLM to retype the array.
        retrieval_results = _pipeline_cache.get("retrieval_results", [])

        similarities = []
        for item in retrieval_results:
            try:
                similarities.append(
                    float(item.get("similarity_score", item.get("similarity", 0)))
                )
            except Exception:
                pass

        best_similarity = max(similarities) if similarities else None

        result = _escalation.evaluate(
            priority=priority,
            sentiment=sentiment,
            category_confidence=float(category_confidence),
            retrieval_similarity=best_similarity,
            ticket_text=ticket_text
        )

        compact = {
            "decision": result.get("decision"),
            "escalation_score": result.get("escalation_score", result.get("score", 0)),
            "reasons": result.get("reasons", []),
            "escalated": result.get("escalated", False),
            "action": (
                "Escalate to human support"
                if result.get("escalated", False)
                else "Automatically handle"
            ),
        }

        return json.dumps(compact, ensure_ascii=False)


# ============================================================
# LEARNING TOOL
# ============================================================

class LearningToolInput(BaseModel):
    """
    LearningTool takes no real arguments. This schema exists because some
    CrewAI/Groq versions generate an invalid function schema ('required'
    present but 'properties' missing) for zero-parameter tools. Declaring
    one optional field with a default guarantees a valid, non-empty
    'properties' object in the generated schema.
    """
    trigger: Optional[str] = Field(
        default="generate_report",
        description="Unused placeholder - this tool always runs the same analytics report.",
    )


class LearningTool(BaseTool):
    name: str = "analyze_support_learning"
    description: str = (
        "Analyze historical customer support performance, including "
        "automation rate, escalation rate, category distribution, "
        "sentiment, confidence, retrieval quality and feedback. "
        "Takes no meaningful arguments."
    )
    args_schema: type[BaseModel] = LearningToolInput

    def _run(self, trigger: Optional[str] = "generate_report") -> str:

        report = _learning.generate_learning_report()

        if isinstance(report, dict):
            compact = {
                "ticket_statistics": report.get("ticket_statistics", {}),
                "automation_rate": report.get("automation_rate", 0),
                "escalation_rate": report.get("escalation_rate", 0),
                "retrieval_statistics": report.get("retrieval_statistics", {}),
                "feedback_statistics": report.get("feedback_statistics", {}),
                "key_categories": report.get("category_statistics", {}),
                "sentiment_statistics": report.get("sentiment_statistics", {}),
                "confidence_statistics": report.get("confidence_statistics", {}),
            }
            return json.dumps(compact, ensure_ascii=False, default=str)

        return json.dumps({"report": str(report)}, ensure_ascii=False)