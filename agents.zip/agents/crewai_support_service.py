import os
import sys
from datetime import datetime

# ---------------------------------------------------------
# Project root setup
# ---------------------------------------------------------
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


# ---------------------------------------------------------
# Real CrewAI orchestration (7 agents, 7 tasks, Process.sequential)
# ---------------------------------------------------------
from agents.crewai_orchestrator import CustomerSupportCrew

# ---------------------------------------------------------
# Existing database layer (unchanged - reused as-is)
# ---------------------------------------------------------
from database.support_database import SupportDatabase


class _PipelineNamespace:
    """
    Minimal shim so api/main.py's `support_service.pipeline.database.*`
    calls keep working without any changes to api/main.py. We deliberately
    do NOT instantiate a full SupportPipeline() here - that would load a
    second copy of IntakeAgent/ClassificationAgent/.../RetrievalAgent
    (including a second FAISS index) alongside the ones crewai_tools.py
    already loads, which is exactly the double-loading problem that was
    already fixed once in the CrewAI orchestrator.
    """
    def __init__(self, database):
        self.database = database


class CrewAISupportService:
    """
    Main service layer used by FastAPI.

    This now actually routes ticket processing through CustomerSupportCrew
    (agents/crewai_orchestrator.py) - the real CrewAI Agent/Task/Crew
    pipeline with Process.sequential - rather than the older SupportPipeline
    direct-Python-calls path. Database persistence and per-agent logging are
    preserved here so /ticket/{id}, /logs/{id}, /stats etc. in api/main.py
    keep working exactly as before.
    """

    def __init__(self):
        print("\nInitializing CrewAI Support Service...")

        self.crew = CustomerSupportCrew()
        self.database = SupportDatabase()

        # Backwards-compatible access path for api/main.py:
        # support_service.pipeline.database.get_ticket(...) etc.
        self.pipeline = _PipelineNamespace(self.database)

        print("CrewAI Support Service initialized successfully.")

    # -----------------------------------------------------
    # Agent logging (same shape/behavior as SupportPipeline.log_agent)
    # -----------------------------------------------------
    def log_agent(
        self,
        ticket_id,
        agent_name,
        status,
        output_summary,
        started_at=None,
        completed_at=None,
    ):
        try:
            self.database.save_agent_log(
                ticket_id=ticket_id,
                agent_name=agent_name,
                status=status,
                output_summary=output_summary,
                started_at=started_at,
                completed_at=completed_at,
            )
        except Exception as e:
            print(f"Warning: Could not save log for {agent_name}: {e}")

    # -----------------------------------------------------
    # Conversation context (same shape as SupportPipeline.build_context_from_result)
    # -----------------------------------------------------
    def build_context_from_result(self, result):
        intake = result.get("intake", {}) or {}
        classification = result.get("classification", {}) or {}
        sentiment = result.get("sentiment", {}) or {}

        entities = intake.get("entities", {})
        if not isinstance(entities, dict):
            entities = {}

        return {
            "category": classification.get("category"),
            "category_confidence": classification.get("category_confidence"),
            "priority": classification.get("priority"),
            "priority_confidence": classification.get("priority_confidence"),
            "sentiment": sentiment.get("sentiment"),
            "sentiment_confidence": sentiment.get("confidence"),
            "intent": intake.get("intent"),
            "urgency": intake.get("urgency"),
            "entities": entities,
            "is_follow_up": True,
        }

    # -----------------------------------------------------
    # Process Ticket (now via real CrewAI orchestration)
    # -----------------------------------------------------
    def process_ticket(self, ticket_text, previous_context=None):

        if not ticket_text or not isinstance(ticket_text, str):
            raise ValueError("ticket_text must be a non-empty string.")

        ticket_text = ticket_text.strip()

        if not ticket_text:
            raise ValueError("ticket_text must be a non-empty string.")

        is_follow_up = bool(previous_context)

        # =================================================
        # RUN THE REAL 7-AGENT CREWAI PIPELINE
        # =================================================
        crew_result = self.crew.process_ticket(ticket_text, previous_context)

        intake_result = crew_result.get("intake", {}) or {}
        classification_result = crew_result.get("classification", {}) or {}
        sentiment_result = crew_result.get("sentiment", {}) or {}
        retrieval_payload = crew_result.get("retrieval", {}) or {}
        response_result = crew_result.get("response")  # plain string from CrewAI
        escalation_result = crew_result.get("escalation", {}) or {}
        learning_report = crew_result.get("learning", {}) or {}

        retrieved_results = retrieval_payload.get("results", [])
        if not isinstance(retrieved_results, list):
            retrieved_results = []

        # -------------------------------------------------
        # FAQ/ticket counts + best similarity, same logic
        # SupportPipeline used to compute
        # -------------------------------------------------
        faq_count = 0
        ticket_count = 0
        similarities = []

        for item in retrieved_results:
            if not isinstance(item, dict):
                continue

            source_type = str(item.get("source_type", "")).upper()
            if source_type == "FAQ":
                faq_count += 1
            elif source_type == "TICKET":
                ticket_count += 1

            similarity = item.get("similarity_score", item.get("similarity"))
            if similarity is not None:
                try:
                    similarities.append(float(similarity))
                except (ValueError, TypeError):
                    pass

        best_similarity = max(similarities) if similarities else 0.0

        result = {
            "ticket": ticket_text,
            "processed_at": datetime.now().isoformat(),
            "is_follow_up": is_follow_up,
            "intake": intake_result,
            "classification": classification_result,
            "sentiment": sentiment_result,
            "retrieval": retrieval_payload,
            "response": response_result,
            "escalation": escalation_result,
        }

        # =================================================
        # SAVE TICKET
        # =================================================
        database_result = None
        try:
            database_result = self.database.save_ticket(result)
        except Exception as e:
            print(f"Warning: Could not save ticket: {e}")

        database_ticket_id = None
        if isinstance(database_result, int):
            database_ticket_id = database_result
        elif isinstance(database_result, dict):
            database_ticket_id = (
                database_result.get("id") or database_result.get("ticket_id")
            )

        result["database_ticket_id"] = database_ticket_id
        result["ticket_id"] = database_ticket_id

        # =================================================
        # SAVE PER-AGENT LOGS
        # =================================================
        if database_ticket_id:
            entities = intake_result.get("entities", {})
            if not isinstance(entities, dict):
                entities = {}

            self.log_agent(
                ticket_id=database_ticket_id,
                agent_name="Intake Agent",
                status="COMPLETED",
                output_summary=(
                    f"Intent: {intake_result.get('intent')}; "
                    f"Urgency: {intake_result.get('urgency')}; "
                    f"Order ID: {entities.get('order_id')}; "
                    f"Product: {entities.get('product')}"
                ),
            )

            self.log_agent(
                ticket_id=database_ticket_id,
                agent_name="Classification Agent",
                status="COMPLETED",
                output_summary=(
                    f"Category: {classification_result.get('category')}; "
                    f"Priority: {classification_result.get('priority')}; "
                    f"Category Confidence: "
                    f"{classification_result.get('category_confidence')}%; "
                    f"Assigned Team: {classification_result.get('assigned_team')}"
                ),
            )

            self.log_agent(
                ticket_id=database_ticket_id,
                agent_name="Sentiment Agent",
                status="COMPLETED",
                output_summary=(
                    f"Sentiment: {sentiment_result.get('sentiment')}; "
                    f"Confidence: {sentiment_result.get('confidence')}%; "
                    f"Signals detected: {len(sentiment_result.get('signals', []) or [])}"
                ),
            )

            self.log_agent(
                ticket_id=database_ticket_id,
                agent_name="Retrieval / RAG Agent",
                status="COMPLETED",
                output_summary=(
                    f"Retrieved {len(retrieved_results)} knowledge items; "
                    f"FAQ results: {faq_count}; "
                    f"Historical ticket results: {ticket_count}; "
                    f"Best similarity: {best_similarity:.4f}"
                ),
            )

            self.log_agent(
                ticket_id=database_ticket_id,
                agent_name="Response Agent",
                status="COMPLETED",
                output_summary=(
                    "Customer response generated via CrewAI Response Agent "
                    "(Groq); grounded in ticket context and retrieved "
                    "support knowledge."
                ),
            )

            self.log_agent(
                ticket_id=database_ticket_id,
                agent_name="Escalation Agent",
                status="COMPLETED",
                output_summary=(
                    f"Decision: {escalation_result.get('decision')}; "
                    f"Score: {escalation_result.get('score')}; "
                    f"Reasons: {', '.join(escalation_result.get('reasons', []) or [])}"
                ),
            )

        # =================================================
        # LEARNING
        # =================================================
        result["learning"] = learning_report

        if database_ticket_id:
            ticket_statistics = learning_report.get("ticket_statistics", {})
            if not isinstance(ticket_statistics, dict):
                ticket_statistics = {}

            total_tickets = ticket_statistics.get("total_tickets", "N/A")
            automation_rate = learning_report.get("automation_rate", "N/A")
            escalation_rate = learning_report.get("escalation_rate", "N/A")

            self.log_agent(
                ticket_id=database_ticket_id,
                agent_name="Learning Agent",
                status="COMPLETED",
                output_summary=(
                    "Learning report generated; "
                    f"Tickets analyzed: {total_tickets}; "
                    f"Automation rate: {automation_rate}%; "
                    f"Escalation rate: {escalation_rate}%"
                ),
            )

        # =================================================
        # CONVERSATION CONTEXT
        # =================================================
        result["conversation_context"] = self.build_context_from_result(result)

        return result


# ---------------------------------------------------------
# Singleton service
# ---------------------------------------------------------
support_service = CrewAISupportService()