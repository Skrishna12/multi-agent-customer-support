import os
import sys
from datetime import datetime


# =========================================================
# PROJECT ROOT
# =========================================================

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


# =========================================================
# AGENTS
# =========================================================

from agents.intake_agent import IntakeAgent
from agents.classification_agent import ClassificationAgent
from agents.sentiment_agent import SentimentAgent
from agents.response_agent import ResponseAgent
from agents.escalation_agent import EscalationAgent
from agents.learning_agent import LearningAgent

from rag.retrieval_agent import RetrievalAgent

from database.support_database import SupportDatabase


# =========================================================
# SUPPORT PIPELINE
# =========================================================

class SupportPipeline:
    """
    Complete Multi-Agent Customer Support Pipeline.

    Flow:

        Customer Ticket
              ↓
        Intake Agent
              ↓
        Classification Agent
              ↓
        Sentiment Agent
              ↓
        Retrieval / RAG Agent
              ↓
        LLM Response Agent
              ↓
        Escalation Agent
              ↓
        Database Logging
              ↓
        Learning Agent
    """

    def __init__(self):

        print("\nInitializing Support Pipeline...")

        self.intake_agent = IntakeAgent()
        self.classification_agent = ClassificationAgent()
        self.sentiment_agent = SentimentAgent()
        self.retrieval_agent = RetrievalAgent()
        self.response_agent = ResponseAgent()
        self.escalation_agent = EscalationAgent()
        self.learning_agent = LearningAgent()

        self.database = SupportDatabase()

        print("Support Pipeline initialized successfully.")

    # =====================================================
    # AGENT LOGGING
    # =====================================================

    def log_agent(
        self,
        ticket_id,
        agent_name,
        status,
        output_summary,
        started_at=None,
        completed_at=None
    ):

        try:

            self.database.save_agent_log(
                ticket_id=ticket_id,
                agent_name=agent_name,
                status=status,
                output_summary=output_summary,
                started_at=started_at,
                completed_at=completed_at
            )

        except Exception as e:

            print(
                f"Warning: Could not save log "
                f"for {agent_name}: {e}"
            )

    # =====================================================
    # BUILD CONVERSATION CONTEXT
    # =====================================================

    def build_context_from_result(self, result):

        intake = result.get("intake", {})
        classification = result.get("classification", {})
        sentiment = result.get("sentiment", {})

        entities = intake.get("entities", {})

        if not isinstance(entities, dict):
            entities = {}

        return {

            "category": classification.get(
                "category"
            ),

            "category_confidence": classification.get(
                "category_confidence"
            ),

            "priority": classification.get(
                "priority"
            ),

            "priority_confidence": classification.get(
                "priority_confidence"
            ),

            "sentiment": sentiment.get(
                "sentiment"
            ),

            "sentiment_confidence": sentiment.get(
                "confidence"
            ),

            "intent": intake.get(
                "intent"
            ),

            "urgency": intake.get(
                "urgency"
            ),

            "entities": entities,

            "is_follow_up": True
        }

    # =====================================================
    # PROCESS TICKET
    # =====================================================

    def process_ticket(
        self,
        ticket_text,
        previous_context=None
    ):

        if not ticket_text:
            raise ValueError(
                "Ticket text cannot be empty."
            )

        if not isinstance(ticket_text, str):
            raise ValueError(
                "Ticket text must be a string."
            )

        ticket_text = ticket_text.strip()

        if not ticket_text:
            raise ValueError(
                "Ticket text cannot be empty."
            )

        is_follow_up = bool(previous_context)

        result = {
            "ticket": ticket_text,
            "processed_at": datetime.now().isoformat(),
            "is_follow_up": is_follow_up
        }

        # =================================================
        # 1. INTAKE AGENT
        # =================================================

        started = datetime.now().isoformat()

        try:

            intake_result = self.intake_agent.process(
                ticket_text,
                previous_context=previous_context
            )

            result["intake"] = intake_result

            completed = datetime.now().isoformat()

            entities = intake_result.get(
                "entities",
                {}
            )

            if not isinstance(entities, dict):
                entities = {}

            self.log_agent(
                ticket_id=None,
                agent_name="Intake Agent",
                status="COMPLETED",
                output_summary=(
                    f"Intent: {intake_result.get('intent')}; "
                    f"Urgency: {intake_result.get('urgency')}; "
                    f"Order ID: {entities.get('order_id')}; "
                    f"Product: {entities.get('product')}"
                ),
                started_at=started,
                completed_at=completed
            )

        except Exception as e:

            self.log_agent(
                ticket_id=None,
                agent_name="Intake Agent",
                status="FAILED",
                output_summary=str(e),
                started_at=started,
                completed_at=datetime.now().isoformat()
            )

            raise

        # =================================================
        # 2. CLASSIFICATION AGENT
        # =================================================

        started = datetime.now().isoformat()

        try:

            classification_result = (
                self.classification_agent.process(
                    ticket_text,
                    previous_context=previous_context
                )
            )

            result["classification"] = classification_result

            completed = datetime.now().isoformat()

            self.log_agent(
                ticket_id=None,
                agent_name="Classification Agent",
                status="COMPLETED",
                output_summary=(
                    f"Category: "
                    f"{classification_result.get('category')}; "
                    f"Priority: "
                    f"{classification_result.get('priority')}; "
                    f"Category Confidence: "
                    f"{classification_result.get('category_confidence')}%; "
                    f"Assigned Team: "
                    f"{classification_result.get('assigned_team')}"
                ),
                started_at=started,
                completed_at=completed
            )

        except Exception as e:

            self.log_agent(
                ticket_id=None,
                agent_name="Classification Agent",
                status="FAILED",
                output_summary=str(e),
                started_at=started,
                completed_at=datetime.now().isoformat()
            )

            raise

        # =================================================
        # 3. SENTIMENT AGENT
        # =================================================

        started = datetime.now().isoformat()

        try:

            sentiment_result = (
                self.sentiment_agent.analyze(
                    ticket_text
                )
            )

            # Preserve negative context for neutral follow-ups.
            if (
                previous_context
                and sentiment_result.get("sentiment") == "Neutral"
                and previous_context.get("sentiment")
                in [
                    "Negative",
                    "Very Negative",
                    "Slightly Negative"
                ]
            ):

                sentiment_result["sentiment"] = (
                    previous_context.get("sentiment")
                )

                sentiment_result["confidence"] = (
                    previous_context.get(
                        "sentiment_confidence",
                        sentiment_result.get("confidence")
                    )
                )

                existing_signals = (
                    sentiment_result.get(
                        "signals",
                        []
                    )
                )

                previous_signals = (
                    previous_context.get(
                        "sentiment_signals",
                        []
                    )
                )

                if not isinstance(existing_signals, list):
                    existing_signals = []

                if not isinstance(previous_signals, list):
                    previous_signals = []

                sentiment_result["signals"] = list(
                    dict.fromkeys(
                        existing_signals + previous_signals
                    )
                )

            result["sentiment"] = sentiment_result

            completed = datetime.now().isoformat()

            self.log_agent(
                ticket_id=None,
                agent_name="Sentiment Agent",
                status="COMPLETED",
                output_summary=(
                    f"Sentiment: "
                    f"{sentiment_result.get('sentiment')}; "
                    f"Confidence: "
                    f"{sentiment_result.get('confidence')}%; "
                    f"Signals detected: "
                    f"{len(sentiment_result.get('signals', []))}"
                ),
                started_at=started,
                completed_at=completed
            )

        except Exception as e:

            self.log_agent(
                ticket_id=None,
                agent_name="Sentiment Agent",
                status="FAILED",
                output_summary=str(e),
                started_at=started,
                completed_at=datetime.now().isoformat()
            )

            raise

        # =================================================
        # 4. RETRIEVAL / RAG AGENT
        # =================================================

        started = datetime.now().isoformat()

        try:

            category = classification_result.get(
                "category"
            )

            retrieval_result = (
                self.retrieval_agent.retrieve(
                    ticket_text,
                    category=category,
                    top_k=5
                )
            )

            result["retrieval"] = retrieval_result

            retrieved_results = []

            if isinstance(retrieval_result, dict):

                retrieved_results = (
                    retrieval_result.get(
                        "results",
                        []
                    )
                )

            elif isinstance(retrieval_result, list):

                retrieved_results = retrieval_result

            if not isinstance(retrieved_results, list):
                retrieved_results = []

            faq_count = 0
            ticket_count = 0
            similarities = []

            for item in retrieved_results:

                if not isinstance(item, dict):
                    continue

                source_type = str(
                    item.get(
                        "source_type",
                        ""
                    )
                ).upper()

                if source_type == "FAQ":
                    faq_count += 1

                elif source_type == "TICKET":
                    ticket_count += 1

                # IMPORTANT:
                # RetrievalAgent returns similarity_score.
                similarity = item.get(
                    "similarity_score"
                )

                # Backward compatibility if another version
                # returns similarity.
                if similarity is None:
                    similarity = item.get(
                        "similarity"
                    )

                if similarity is not None:

                    try:
                        similarities.append(
                            float(similarity)
                        )

                    except (ValueError, TypeError):
                        pass

            best_similarity = (
                max(similarities)
                if similarities
                else 0.0
            )

            completed = datetime.now().isoformat()

            self.log_agent(
                ticket_id=None,
                agent_name="Retrieval / RAG Agent",
                status="COMPLETED",
                output_summary=(
                    f"Retrieved "
                    f"{len(retrieved_results)} "
                    f"knowledge items; "
                    f"FAQ results: "
                    f"{faq_count}; "
                    f"Historical ticket results: "
                    f"{ticket_count}; "
                    f"Best similarity: "
                    f"{best_similarity:.4f}"
                ),
                started_at=started,
                completed_at=completed
            )

        except Exception as e:

            self.log_agent(
                ticket_id=None,
                agent_name="Retrieval / RAG Agent",
                status="FAILED",
                output_summary=str(e),
                started_at=started,
                completed_at=datetime.now().isoformat()
            )

            raise

        # =================================================
        # 5. LLM RESPONSE AGENT
        # =================================================

        started = datetime.now().isoformat()

        try:

            response_result = (
                self.response_agent.generate_response(

                    ticket=ticket_text,

                    category=(
                        classification_result.get(
                            "category"
                        )
                    ),

                    priority=(
                        classification_result.get(
                            "priority"
                        )
                    ),

                    sentiment=(
                        sentiment_result.get(
                            "sentiment"
                        )
                    ),

                    retrieved_results=(
                        retrieved_results
                    ),

                    intent=(
                        intake_result.get(
                            "intent"
                        )
                    ),

                    conversation_context=(
                        previous_context
                    )
                )
            )

            result["response"] = response_result

            completed = datetime.now().isoformat()

            response_source = (
                response_result.get(
                    "source",
                    "Unknown"
                )
                if isinstance(response_result, dict)
                else "Unknown"
            )

            model = (
                response_result.get("model")
                if isinstance(response_result, dict)
                else None
            )

            model_text = (
                f"; Model: {model}"
                if model
                else ""
            )

            self.log_agent(
                ticket_id=None,
                agent_name="Response Agent",
                status="COMPLETED",
                output_summary=(
                    "Customer response generated "
                    f"using {response_source}"
                    f"{model_text}; "
                    "ticket context and retrieved "
                    "support knowledge."
                ),
                started_at=started,
                completed_at=completed
            )

        except Exception as e:

            self.log_agent(
                ticket_id=None,
                agent_name="Response Agent",
                status="FAILED",
                output_summary=str(e),
                started_at=started,
                completed_at=datetime.now().isoformat()
            )

            raise

        # =================================================
        # 6. ESCALATION AGENT
        # =================================================

        started = datetime.now().isoformat()

        try:

            escalation_result = (
                self.escalation_agent.evaluate(

                    priority=(
                        classification_result.get(
                            "priority"
                        )
                    ),

                    sentiment=(
                        sentiment_result.get(
                            "sentiment"
                        )
                    ),

                    category_confidence=(
                        classification_result.get(
                            "category_confidence",
                            0
                        )
                    ),

                    retrieval_similarity=(
                        best_similarity
                    ),

                    ticket_text=ticket_text
                )
            )

            result["escalation"] = escalation_result

            completed = datetime.now().isoformat()

            self.log_agent(
                ticket_id=None,
                agent_name="Escalation Agent",
                status="COMPLETED",
                output_summary=(
                    f"Decision: "
                    f"{escalation_result.get('decision')}; "
                    f"Score: "
                    f"{escalation_result.get('score')}; "
                    f"Reasons: "
                    f"{', '.join(escalation_result.get('reasons', []))}"
                ),
                started_at=started,
                completed_at=completed
            )

        except Exception as e:

            self.log_agent(
                ticket_id=None,
                agent_name="Escalation Agent",
                status="FAILED",
                output_summary=str(e),
                started_at=started,
                completed_at=datetime.now().isoformat()
            )

            raise

        # =================================================
        # 7. SAVE TO DATABASE
        # =================================================

        database_result = None

        try:

            database_result = (
                self.database.save_ticket(
                    result
                )
            )

        except Exception as e:

            print(
                f"Warning: Could not save ticket: {e}"
            )

        # =================================================
        # 8. DATABASE TICKET ID
        # =================================================

        database_ticket_id = None

        if isinstance(database_result, int):

            database_ticket_id = database_result

        elif isinstance(database_result, dict):

            database_ticket_id = (
                database_result.get("id")
                or database_result.get("ticket_id")
            )

        # IMPORTANT:
        # Expose BOTH names so API/UI/older code can use
        # either convention.
        result["database_ticket_id"] = (
            database_ticket_id
        )

        result["ticket_id"] = (
            database_ticket_id
        )

        # =================================================
        # 9. SAVE ACTUAL AGENT LOGS
        # =================================================

        if database_ticket_id:

            entities = intake_result.get(
                "entities",
                {}
            )

            if not isinstance(entities, dict):
                entities = {}

            # Intake
            self.log_agent(
                ticket_id=database_ticket_id,
                agent_name="Intake Agent",
                status="COMPLETED",
                output_summary=(
                    f"Intent: {intake_result.get('intent')}; "
                    f"Urgency: {intake_result.get('urgency')}; "
                    f"Order ID: {entities.get('order_id')}; "
                    f"Product: {entities.get('product')}"
                )
            )

            # Classification
            self.log_agent(
                ticket_id=database_ticket_id,
                agent_name="Classification Agent",
                status="COMPLETED",
                output_summary=(
                    f"Category: "
                    f"{classification_result.get('category')}; "
                    f"Priority: "
                    f"{classification_result.get('priority')}; "
                    f"Category Confidence: "
                    f"{classification_result.get('category_confidence')}%; "
                    f"Assigned Team: "
                    f"{classification_result.get('assigned_team')}"
                )
            )

            # Sentiment
            self.log_agent(
                ticket_id=database_ticket_id,
                agent_name="Sentiment Agent",
                status="COMPLETED",
                output_summary=(
                    f"Sentiment: "
                    f"{sentiment_result.get('sentiment')}; "
                    f"Confidence: "
                    f"{sentiment_result.get('confidence')}%; "
                    f"Signals detected: "
                    f"{len(sentiment_result.get('signals', []))}"
                )
            )

            # RAG
            self.log_agent(
                ticket_id=database_ticket_id,
                agent_name="Retrieval / RAG Agent",
                status="COMPLETED",
                output_summary=(
                    f"Retrieved "
                    f"{len(retrieved_results)} "
                    f"knowledge items; "
                    f"FAQ results: "
                    f"{faq_count}; "
                    f"Historical ticket results: "
                    f"{ticket_count}; "
                    f"Best similarity: "
                    f"{best_similarity:.4f}"
                )
            )

            # Response
            response_source = (
                response_result.get(
                    "source",
                    "Unknown"
                )
                if isinstance(response_result, dict)
                else "Unknown"
            )

            model = (
                response_result.get("model")
                if isinstance(response_result, dict)
                else None
            )

            model_text = (
                f"; Model: {model}"
                if model
                else ""
            )

            self.log_agent(
                ticket_id=database_ticket_id,
                agent_name="Response Agent",
                status="COMPLETED",
                output_summary=(
                    "Customer response generated "
                    f"using {response_source}"
                    f"{model_text}; "
                    "ticket context and retrieved "
                    "support knowledge."
                )
            )

            # Escalation
            self.log_agent(
                ticket_id=database_ticket_id,
                agent_name="Escalation Agent",
                status="COMPLETED",
                output_summary=(
                    f"Decision: "
                    f"{escalation_result.get('decision')}; "
                    f"Score: "
                    f"{escalation_result.get('score')}; "
                    f"Reasons: "
                    f"{', '.join(escalation_result.get('reasons', []))}"
                )
            )

        # =================================================
        # 10. LEARNING AGENT
        # =================================================

        started = datetime.now().isoformat()

        try:

            learning_report = (
                self.learning_agent
                .generate_learning_report()
            )

            result["learning"] = learning_report

            completed = datetime.now().isoformat()

            if isinstance(learning_report, dict):

                ticket_statistics = (
                    learning_report.get(
                        "ticket_statistics",
                        {}
                    )
                )

                if not isinstance(
                    ticket_statistics,
                    dict
                ):
                    ticket_statistics = {}

                total_tickets = (
                    ticket_statistics.get(
                        "total_tickets",
                        "N/A"
                    )
                )

                automation_rate = (
                    learning_report.get(
                        "automation_rate",
                        "N/A"
                    )
                )

                escalation_rate = (
                    learning_report.get(
                        "escalation_rate",
                        "N/A"
                    )
                )

            else:

                total_tickets = "N/A"
                automation_rate = "N/A"
                escalation_rate = "N/A"

            if database_ticket_id:

                self.log_agent(
                    ticket_id=database_ticket_id,
                    agent_name="Learning Agent",
                    status="COMPLETED",
                    output_summary=(
                        "Learning report generated; "
                        f"Tickets analyzed: "
                        f"{total_tickets}; "
                        f"Automation rate: "
                        f"{automation_rate}%; "
                        f"Escalation rate: "
                        f"{escalation_rate}%"
                    ),
                    started_at=started,
                    completed_at=completed
                )

        except Exception as e:

            print(
                f"Warning: Learning Agent failed: {e}"
            )

            result["learning"] = {
                "error": str(e)
            }

            if database_ticket_id:

                self.log_agent(
                    ticket_id=database_ticket_id,
                    agent_name="Learning Agent",
                    status="FAILED",
                    output_summary=str(e),
                    started_at=started,
                    completed_at=datetime.now().isoformat()
                )

        # =================================================
        # 11. FINAL CONVERSATION CONTEXT
        # =================================================

        result["conversation_context"] = (
            self.build_context_from_result(
                result
            )
        )

        # =================================================
        # FINAL RESULT
        # =================================================

        return result