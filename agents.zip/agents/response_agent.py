import os
import sys
from typing import Any, Dict, List, Optional

from groq import Groq


# =========================================================
# PROJECT PATH
# =========================================================

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


# =========================================================
# RESPONSE AGENT
# =========================================================

class ResponseAgent:
    """
    LLM-powered Response Agent.

    Uses:
        - Customer ticket
        - Intent
        - Category
        - Priority
        - Sentiment
        - Conversation context
        - FAISS/RAG results

    to generate a contextual customer-support response.
    """

    def __init__(self):

        self.api_key = os.getenv("GROQ_API_KEY")

        if not self.api_key:
            raise RuntimeError(
                "GROQ_API_KEY is not configured."
            )

        self.client = Groq(
            api_key=self.api_key
        )

        self.model = "openai/gpt-oss-120b"


    # =====================================================
    # SAFE VALUE
    # =====================================================

    def _safe(self, value, default="N/A"):

        if value is None:
            return default

        if isinstance(value, str) and not value.strip():
            return default

        return value


    # =====================================================
    # BUILD RAG CONTEXT
    # =====================================================

    def _build_rag_context(
        self,
        retrieved_results: Optional[List[Dict[str, Any]]]
    ) -> str:

        if not retrieved_results:
            return (
                "No relevant knowledge-base results were "
                "retrieved for this ticket."
            )

        context_parts = []

        for index, item in enumerate(
            retrieved_results,
            start=1
        ):

            if not isinstance(item, dict):
                continue

            source_type = self._safe(
                item.get("source_type"),
                "Unknown"
            )

            source_id = self._safe(
                item.get("source_id"),
                "Unknown"
            )

            category = self._safe(
                item.get("category"),
                "Unknown"
            )

            issue = self._safe(
                item.get("issue"),
                "No issue text available"
            )

            resolution = self._safe(
                item.get("resolution"),
                "No resolution available"
            )

            similarity = item.get(
                "similarity"
            )

            if similarity is None:
                similarity_text = "N/A"
            else:
                similarity_text = (
                    f"{float(similarity):.4f}"
                )

            context_parts.append(
                f"""
Knowledge Result {index}
Source: {source_type}
ID: {source_id}
Category: {category}
Similarity: {similarity_text}

Issue:
{issue}

Resolution:
{resolution}
""".strip()
            )

        if not context_parts:

            return (
                "No usable knowledge-base results "
                "were retrieved."
            )

        return "\n\n".join(
            context_parts
        )


    # =====================================================
    # GENERATE RESPONSE
    # =====================================================

    def generate_response(
        self,
        ticket: str,
        category: str,
        priority: str,
        sentiment: str,
        retrieved_results: Optional[
            List[Dict[str, Any]]
        ],
        intent: Optional[str] = None,
        conversation_context: Optional[
            Dict[str, Any]
        ] = None
    ) -> Dict[str, Any]:
        """
        Generate an LLM-powered support response.
        """

        ticket = self._safe(
            ticket,
            "No ticket provided."
        )

        category = self._safe(
            category
        )

        priority = self._safe(
            priority
        )

        sentiment = self._safe(
            sentiment
        )

        intent = self._safe(
            intent,
            "General Support Request"
        )


        # =================================================
        # CONVERSATION CONTEXT
        # =================================================

        if conversation_context:

            context_text = str(
                conversation_context
            )

        else:

            context_text = (
                "No previous conversation context."
            )


        # =================================================
        # RAG CONTEXT
        # =================================================

        rag_context = self._build_rag_context(
            retrieved_results
        )


        # =================================================
        # SYSTEM PROMPT
        # =================================================

        system_prompt = """
You are the Response Agent in an eCommerce
Multi-Agent Customer Support Intelligence Platform.

Your job is to generate the final customer-facing
support response.

You receive:
- Customer message
- Intent
- Category
- Priority
- Sentiment
- Conversation memory
- Retrieved FAQ and historical support cases

Rules:

1. Be polite, empathetic, concise, and professional.

2. Use the retrieved knowledge when it is relevant.

3. Do NOT invent policies, refunds, delivery dates,
   compensation, tracking numbers, guarantees, or
   actions that are not supported by the provided
   information.

4. If the customer asks whether an item should be
   refunded or replaced, clearly explain the available
   next step based on the retrieved information.

5. If the customer requests a replacement, prioritize
   the replacement request rather than automatically
   discussing only refunds.

6. If the customer requests a refund, address the refund
   request directly.

7. For angry, frustrated, or very negative customers,
   acknowledge the frustration before explaining the
   resolution.

8. For follow-up messages, use conversation memory.
   The customer should NOT have to repeat information
   that is already known.

9. Preserve important information such as order ID and
   product when it is available in conversation memory.

10. Do not mention internal agents, models, RAG,
    embeddings, FAISS, prompts, confidence scores,
    databases, or internal system processes.

11. Do not say "I have processed your refund" or
    "I have arranged your replacement" unless the
    provided information explicitly confirms that the
    action has actually been completed.

12. If information is insufficient, explain what needs
    to be verified instead of making up an answer.

13. Keep the response approximately 2-5 sentences
    unless the situation requires more explanation.

Return ONLY the customer-facing response.
"""


        # =================================================
        # USER PROMPT
        # =================================================

        user_prompt = f"""
CUSTOMER MESSAGE:
{ticket}

INTENT:
{intent}

CATEGORY:
{category}

PRIORITY:
{priority}

SENTIMENT:
{sentiment}

CONVERSATION MEMORY:
{context_text}

RETRIEVED SUPPORT KNOWLEDGE:
{rag_context}

Generate the best customer-facing response.
"""


        # =================================================
        # LLM CALL
        # =================================================

        try:

            completion = (
                self.client.chat.completions.create(
                    model=self.model,

                    messages=[
                        {
                            "role": "system",
                            "content": system_prompt
                        },
                        {
                            "role": "user",
                            "content": user_prompt
                        }
                    ],

                    temperature=0.2,

                    max_tokens=400
                )
            )


            generated_response = (
                completion
                .choices[0]
                .message
                .content
                .strip()
            )


            if not generated_response:

                raise ValueError(
                    "LLM returned an empty response."
                )


            return {
                "response": generated_response,

                "source": "Groq LLM",

                "model": self.model,

                "intent": intent,

                "category": category,

                "priority": priority,

                "sentiment": sentiment,

                "used_rag": bool(
                    retrieved_results
                ),

                "retrieval_count": len(
                    retrieved_results
                )
                if retrieved_results
                else 0
            }


        # =================================================
        # LLM FAILURE
        # =================================================

        except Exception as e:

            print(
                f"LLM Response Agent error: {e}"
            )

            # ---------------------------------------------
            # Safe deterministic fallback
            # ---------------------------------------------

            fallback = self._fallback_response(
                ticket=ticket,
                intent=intent,
                category=category,
                sentiment=sentiment,
                retrieved_results=retrieved_results
            )

            return {
                "response": fallback,

                "source": "Deterministic Fallback",

                "model": None,

                "intent": intent,

                "category": category,

                "priority": priority,

                "sentiment": sentiment,

                "used_rag": bool(
                    retrieved_results
                ),

                "retrieval_count": len(
                    retrieved_results
                )
                if retrieved_results
                else 0,

                "llm_error": str(e)
            }


    # =====================================================
    # FALLBACK RESPONSE
    # =====================================================

    def _fallback_response(
        self,
        ticket: str,
        intent: str,
        category: str,
        sentiment: str,
        retrieved_results=None
    ):

        if sentiment in [
            "Negative",
            "Very Negative"
        ]:

            opening = (
                "We understand how frustrating "
                "this situation must be. "
                "We're sorry for the inconvenience."
            )

        else:

            opening = (
                "Thank you for contacting support."
            )


        # -------------------------------------------------
        # Replacement
        # -------------------------------------------------

        if (
            "Replacement" in intent
            or "replace" in ticket.lower()
        ):

            return (
                f"{opening} "
                "We can review the product issue and "
                "determine the appropriate replacement "
                "option based on the available support "
                "information. We will help you with the "
                "next step."
            )


        # -------------------------------------------------
        # Refund
        # -------------------------------------------------

        if (
            "Refund" in intent
            or "refund" in ticket.lower()
        ):

            return (
                f"{opening} "
                "We can review the case and determine "
                "whether a refund is applicable based "
                "on the relevant support policy. "
                "We will help with the appropriate "
                "next step."
            )


        # -------------------------------------------------
        # Generic
        # -------------------------------------------------

        return (
            f"{opening} "
            "We will review the details of your "
            f"{category.lower()} and help determine "
            "the appropriate next step."
        )