import re


class IntakeAgent:
    """
    Conversation-aware Intake Agent.

    Responsibilities:
    - Clean customer text
    - Extract order ID
    - Extract product
    - Detect customer intent
    - Detect urgency
    - Detect sentiment
    - Understand follow-up messages using previous ticket context
    """

    URGENT_KEYWORDS = [
        "immediately",
        "urgent",
        "urgently",
        "as soon as possible",
        "right away",
        "today",
        "emergency",
        "critical",
        "now",
    ]

    HIGH_SEVERITY_KEYWORDS = [
        "fraud",
        "scam",
        "counterfeit",
        "stolen",
        "identity theft",
        "hacked",
        "unauthorized",
        "dangerous",
        "threat",
        "legal",
        "lawsuit",
        "police",
    ]

    INTENT_PATTERNS = {
        "Refund Request": [
            "refund",
            "money back",
            "give my money back",
            "get my money back",
            "reimburse",
            "reimbursement",
            "charged twice",
            "double charged",
            "duplicate charge",
        ],
        "Replacement Request": [
            "replacement",
            "replace it",
            "replace this",
            "replace the product",
            "exchange",
            "swap it",
            "new one",
        ],
        "Return Request": [
            "return",
            "send it back",
            "return the product",
            "return this",
        ],
        "Delivery Tracking": [
            "where is my order",
            "track my order",
            "tracking",
            "track order",
            "shipment status",
            "delivery status",
            "where is the package",
            "where is my package",
        ],
        "Delivery Complaint": [
            "delivery is late",
            "delivery was late",
            "delayed delivery",
            "order is late",
            "order was late",
            "not delivered",
            "not received",
            "haven't received",
            "hasn't arrived",
            "didn't arrive",
            "not arrived",
            "arrive",
            "delivery problem",
        ],
        "Payment Issue": [
            "payment failed",
            "payment failure",
            "payment issue",
            "charged twice",
            "double charged",
            "duplicate payment",
            "wrong charge",
            "incorrect charge",
            "card charged",
            "charged my card",
        ],
        "Account/Login Issue": [
            "can't login",
            "cannot login",
            "cannot log in",
            "can't log in",
            "login issue",
            "login problem",
            "forgot password",
            "password reset",
            "account locked",
            "can't access my account",
            "cannot access my account",
        ],
        "Product Issue": [
            "damaged",
            "broken",
            "defective",
            "faulty",
            "cracked",
            "not working",
            "doesn't work",
            "does not work",
            "malfunction",
            "wrong product",
            "wrong item",
            "different product",
            "missing parts",
            "missing item",
        ],
        "Product Information": [
            "product information",
            "product details",
            "specifications",
            "specification",
            "features",
            "compatible",
            "compatibility",
            "available",
            "in stock",
        ],
        "Seller Complaint": [
            "seller",
            "seller complaint",
            "seller issue",
            "seller problem",
            "seller behavior",
        ],
        "Website/App Issue": [
            "website",
            "app",
            "application",
            "page is not loading",
            "website is not working",
            "app is not working",
            "app crashed",
            "error on the website",
            "error on the app",
        ],
    }

    PRODUCT_KEYWORDS = [
        "wireless headphones",
        "wireless earbuds",
        "headphones",
        "earbuds",
        "smartphone",
        "phone",
        "laptop",
        "tablet",
        "smartwatch",
        "watch",
        "keyboard",
        "mouse",
        "charger",
        "power bank",
        "camera",
        "television",
        "tv",
        "monitor",
        "printer",
        "speaker",
        "resistance bands",
        "running shoes",
        "shoes",
        "backpack",
        "water bottle",
        "coffee maker",
        "air fryer",
        "fitness tracker",
    ]

    def clean_text(self, text):
        """
        Basic text normalization while preserving useful information.
        """
        if not text:
            return ""

        text = str(text).strip()
        text = re.sub(r"\s+", " ", text)

        return text

    def extract_order_id(self, text):
        """
        Extract order IDs such as:
        ORD7824512
        #ORD7824512
        order #ORD7824512
        """
        if not text:
            return None

        pattern = r"\bORD\d{6,}\b"
        match = re.search(pattern, text.upper())

        if match:
            return match.group(0)

        return None

    def extract_product(self, text):
        """
        Extract a known product from the customer message.
        """
        if not text:
            return None

        text_lower = text.lower()

        # Check longer product names first.
        sorted_products = sorted(
            self.PRODUCT_KEYWORDS,
            key=len,
            reverse=True
        )

        for product in sorted_products:
            if product in text_lower:
                return product.title()

        return None

    def extract_intent(self, text):
        """
        Detect the customer's primary intent.

        Important:
        More specific/action-oriented intents are checked before
        general delivery/payment complaints.
        """
        if not text:
            return "General Inquiry"

        text_lower = text.lower()

        # Follow-up action requests should take priority.
        priority_order = [
            "Replacement Request",
            "Refund Request",
            "Return Request",
            "Payment Issue",
            "Delivery Tracking",
            "Delivery Complaint",
            "Account/Login Issue",
            "Product Issue",
            "Product Information",
            "Seller Complaint",
            "Website/App Issue",
        ]

        scores = {}

        for intent in priority_order:
            score = 0

            for phrase in self.INTENT_PATTERNS[intent]:
                if phrase in text_lower:
                    score += 1

            scores[intent] = score

        best_intent = max(scores, key=scores.get)

        if scores[best_intent] > 0:
            return best_intent

        return "General Inquiry"

    def extract_urgency(self, text):
        """
        Detect urgency level and supporting signals.
        """
        if not text:
            return {
                "level": "Low",
                "confidence": 50,
                "signals": []
            }

        text_lower = text.lower()

        urgent_matches = [
            keyword
            for keyword in self.URGENT_KEYWORDS
            if keyword in text_lower
        ]

        high_severity_matches = [
            keyword
            for keyword in self.HIGH_SEVERITY_KEYWORDS
            if keyword in text_lower
        ]

        signals = urgent_matches + high_severity_matches

        if high_severity_matches:
            return {
                "level": "High",
                "confidence": 95,
                "signals": signals
            }

        if urgent_matches:
            return {
                "level": "High",
                "confidence": 90,
                "signals": signals
            }

        return {
            "level": "Low",
            "confidence": 60,
            "signals": []
        }

    def extract_sentiment(self, text):
        """
        Lightweight explainable sentiment detection.
        """
        if not text:
            return {
                "sentiment": "Neutral",
                "confidence": 60,
                "signals": []
            }

        text_lower = text.lower()

        very_negative_words = [
            "fraud",
            "scam",
            "counterfeit",
            "fake",
            "stolen",
            "identity theft",
            "hacked",
            "furious",
            "terrible",
            "worst",
            "unacceptable",
            "angry",
            "cheated",
            "dangerous",
            "threat",
        ]

        negative_words = [
            "damaged",
            "broken",
            "defective",
            "missing",
            "failed",
            "error",
            "wrong",
            "disappointed",
            "frustrating",
            "frustrated",
            "delay",
            "delayed",
            "late",
            "not received",
            "haven't received",
            "hasn't arrived",
            "didn't arrive",
            "not arrived",
            "cannot",
            "can't",
            "unable",
            "not working",
            "doesn't work",
            "does not work",
            "malfunction",
            "cracked",
            "faulty",
            "problem",
            "issue",
            "complaint",
        ]

        positive_words = [
            "thank you",
            "thanks",
            "great",
            "excellent",
            "happy",
            "satisfied",
            "helpful",
            "good service",
            "resolved successfully",
            "fixed successfully",
            "appreciate your help",
        ]

        very_negative_matches = [
            word
            for word in very_negative_words
            if word in text_lower
        ]

        negative_matches = [
            word
            for word in negative_words
            if word in text_lower
        ]

        positive_matches = [
            word
            for word in positive_words
            if word in text_lower
        ]

        if very_negative_matches:
            return {
                "sentiment": "Very Negative",
                "confidence": min(
                    90 + len(very_negative_matches) * 2,
                    99
                ),
                "signals": very_negative_matches
            }

        if negative_matches and positive_matches:
            return {
                "sentiment": "Slightly Negative",
                "confidence": 70,
                "signals": negative_matches
            }

        if negative_matches:
            return {
                "sentiment": "Negative",
                "confidence": min(
                    70 + len(negative_matches) * 5,
                    90
                ),
                "signals": negative_matches
            }

        if positive_matches:
            return {
                "sentiment": "Positive",
                "confidence": min(
                    75 + len(positive_matches) * 5,
                    95
                ),
                "signals": positive_matches
            }

        return {
            "sentiment": "Neutral",
            "confidence": 60,
            "signals": []
        }

    def extract_entities(self, text, previous_context=None):
        """
        Extract entities from the current message.

        If an entity is missing from a follow-up message,
        reuse the entity from the previous ticket context.
        """
        previous_context = previous_context or {}

        order_id = self.extract_order_id(text)
        product = self.extract_product(text)

        previous_entities = previous_context.get("entities", {})

        if not order_id:
            order_id = previous_entities.get("order_id")

        if not product:
            product = previous_entities.get("product")

        return {
            "order_id": order_id,
            "product": product
        }

    def process(self, ticket_text, previous_context=None):
        """
        Process a customer message.

        previous_context is optional and should contain the previous
        ticket analysis when this is a follow-up message.
        """
        previous_context = previous_context or {}

        cleaned_text = self.clean_text(ticket_text)

        entities = self.extract_entities(
            cleaned_text,
            previous_context
        )

        intent = self.extract_intent(cleaned_text)

        urgency = self.extract_urgency(cleaned_text)

        sentiment = self.extract_sentiment(cleaned_text)

        return {
            "original_text": ticket_text,
            "cleaned_text": cleaned_text,
            "intent": intent,
            "urgency": urgency,
            "sentiment": sentiment,
            "entities": entities,
            "is_follow_up": bool(previous_context)
        }


if __name__ == "__main__":
    agent = IntakeAgent()

    print("\n===== INITIAL MESSAGE =====")

    original_ticket = (
        "Order #ORD7824512 was supposed to arrive 3 days ago "
        "but the tracking hasn't updated. I was also charged twice "
        "for my wireless headphones. I'm extremely frustrated and "
        "I want a refund immediately."
    )

    first_result = agent.process(original_ticket)

    print(first_result)

    print("\n===== FOLLOW-UP MESSAGE =====")

    follow_up = "Can I get a replacement instead of a refund?"

    second_result = agent.process(
        follow_up,
        previous_context=first_result
    )

    print(second_result)