# agents/escalation_agent.py

class EscalationAgent:
    """
    Decides whether a support ticket should be automatically handled
    or escalated to a human support agent.
    """

    def __init__(self):
        self.name = "Escalation Agent"

        # Threshold for escalation
        self.escalation_threshold = 50

        # Complexity indicators
        self.complexity_keywords = [
            "legal",
            "lawyer",
            "court",
            "complaint",
            "consumer court",
            "police",
            "fraud",
            "scam",
            "chargeback",
            "regulator",
            "regulatory",
            "formal complaint",
            "compensation",
            "compensate",
            "third time",
            "multiple times",
            "again and again",
            "still not resolved",
            "not resolved",
            "supervisor",
            "manager",
        ]

    def evaluate(
        self,
        priority=None,
        sentiment=None,
        category_confidence=None,
        retrieval_similarity=None,
        ticket_text="",
        complexity=None,
        **kwargs
    ):
        """
        Evaluate whether a ticket should be escalated.

        Supports both the current SupportPipeline call and older
        calling conventions through optional parameters.
        """

        score = 0
        reasons = []

        # ---------------------------------------------------------
        # 1. PRIORITY
        # ---------------------------------------------------------
        if priority:
            priority_value = str(priority).strip().lower()

            if priority_value == "high":
                score += 30
                reasons.append("High priority ticket")

            elif priority_value == "medium":
                score += 10

        # ---------------------------------------------------------
        # 2. SENTIMENT
        # ---------------------------------------------------------
        if sentiment:
            sentiment_value = str(sentiment).strip().lower()

            if sentiment_value == "very negative":
                score += 40
                reasons.append("Very negative customer sentiment")

            elif sentiment_value == "negative":
                score += 25
                reasons.append("Negative customer sentiment")

            elif sentiment_value == "slightly negative":
                score += 10
                reasons.append("Slightly negative customer sentiment")

        # ---------------------------------------------------------
        # 3. CATEGORY CONFIDENCE
        # ---------------------------------------------------------
        confidence = None

        if category_confidence is not None:
            try:
                confidence = float(category_confidence)

                # Accept both 0-1 and 0-100 formats
                if confidence <= 1:
                    confidence *= 100

            except (ValueError, TypeError):
                confidence = None

        if confidence is not None and confidence < 60:
            score += 25
            reasons.append(
                f"Low category confidence ({confidence:.1f}%)"
            )

        # ---------------------------------------------------------
        # 4. RETRIEVAL QUALITY
        # ---------------------------------------------------------
        similarity = None

        if retrieval_similarity is not None:
            try:
                similarity = float(retrieval_similarity)
            except (ValueError, TypeError):
                similarity = None

        if similarity is None:
            # No reliable retrieval evidence
            score += 30
            reasons.append("No reliable knowledge retrieval")

        elif similarity < 0.45:
            score += 25
            reasons.append(
                f"Low knowledge retrieval similarity ({similarity:.2f})"
            )

        # ---------------------------------------------------------
        # 5. COMPLEXITY
        # ---------------------------------------------------------
        text = str(ticket_text or "").lower()

        detected_complexity = False

        for keyword in self.complexity_keywords:
            if keyword in text:
                detected_complexity = True
                break

        if complexity is True:
            detected_complexity = True

        if detected_complexity:
            score += 35
            reasons.append("Complex or sensitive support case")

        # ---------------------------------------------------------
        # 6. FINAL DECISION
        # ---------------------------------------------------------
        if score >= self.escalation_threshold:
            decision = "ESCALATE"
        else:
            decision = "AUTO-HANDLE"

        # Remove duplicate reasons while preserving order
        reasons = list(dict.fromkeys(reasons))

        # ---------------------------------------------------------
        # 7. RESULT
        # ---------------------------------------------------------
        return {
            "decision": decision,
            "score": score,
            "threshold": self.escalation_threshold,
            "reasons": reasons,
            "reason": "; ".join(reasons)
            if reasons
            else "Ticket can be automatically handled",
            "escalated": decision == "ESCALATE",
            "priority": priority,
            "sentiment": sentiment,
            "category_confidence": confidence,
            "retrieval_similarity": similarity,
        }