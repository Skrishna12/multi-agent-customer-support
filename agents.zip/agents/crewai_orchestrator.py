# agents/crewai_orchestrator.py

import os

os.environ.setdefault("OTEL_SDK_DISABLED", "true")

import crewai.llms.cache as _crewai_cache

_crewai_cache.mark_cache_breakpoint = lambda msg: msg

import sys

from crewai import Crew, Process
import json


def _safe_json_object(raw: str) -> dict:
    """Parses a task's raw string output as a JSON object. Returns {} on failure."""
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else {}
    except (json.JSONDecodeError, TypeError):
        return {}


def _safe_json_list(raw: str) -> list:
    """Parses a task's raw string output as a JSON array. Returns [] on failure."""
    if not raw:
        return []
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, list) else []
    except (json.JSONDecodeError, TypeError):
        return []


def _task_raw(crew_output, index: int) -> str:
    """Pulls the raw string output of the Nth task from a CrewOutput, defensively."""
    try:
        return crew_output.tasks_output[index].raw or ""
    except (AttributeError, IndexError, TypeError):
        return ""


# =========================================================
# PROJECT ROOT
# =========================================================

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


# =========================================================
# CREWAI COMPONENTS
# =========================================================

from agents.crewai_agents import create_crewai_agents

from agents.crewai_tools import (
    IntakeTool,
    ClassificationTool,
    SentimentTool,
    RetrievalTool,
    ResponseTool,
    EscalationTool,
    LearningTool,
    set_request_context,
)

from agents.crewai_tasks import CustomerSupportCrewTasks


# =========================================================
# CUSTOMER SUPPORT CREW
# =========================================================

class CustomerSupportCrew:

    def __init__(self):

        print("\nInitializing CrewAI Customer Support System...")

        # -------------------------------------------------
        # Actual CrewAI agents using Groq
        # -------------------------------------------------

        self.agents = create_crewai_agents()

        # -------------------------------------------------
        # Tools. NOTE: each tool class in crewai_tools.py owns its
        # own single module-level instance of the underlying
        # IntakeAgent/ClassificationAgent/.../RetrievalAgent etc.
        # (loaded once when crewai_tools is imported). Do NOT also
        # instantiate those agents here or pass them into the tool
        # constructors - that previously caused the FAISS index and
        # every model to load twice (visible in the old logs as
        # "FAISS documents loaded: 10150" printed twice), which
        # slowed startup and wasted memory for no benefit.
        # -------------------------------------------------

        self.tools = {
            "intake": IntakeTool(),
            "classification": ClassificationTool(),
            "sentiment": SentimentTool(),
            "retrieval": RetrievalTool(),
            "response": ResponseTool(),
            "escalation": EscalationTool(),
            "learning": LearningTool(),
        }

        print("CrewAI Customer Support System initialized successfully.")

    # =====================================================
    # BUILD CREW
    # =====================================================

    def build_crew(self, ticket_text, previous_context=None):

        if not ticket_text:
            raise ValueError("Ticket text cannot be empty.")

        # Ground truth for IntakeTool - see crewai_tools.py's
        # _request_context comment for why this bypasses the LLM.
        set_request_context(ticket_text, previous_context)

        # If this is a follow-up message, prepend a short summary of the
        # prior turn so Intake (and everything downstream, since they all
        # read from Intake's cleaned_text) has that context available.
        effective_text = ticket_text
        if previous_context:
            entities = previous_context.get("entities") or {}
            order_id = entities.get("order_id") if isinstance(entities, dict) else None
            context_summary = (
                f"[Follow-up to a previous ticket. Prior category: "
                f"{previous_context.get('category')}, priority: "
                f"{previous_context.get('priority')}, sentiment: "
                f"{previous_context.get('sentiment')}"
                + (f", order_id: {order_id}" if order_id else "")
                + "]\n\nCustomer's new message: "
                + ticket_text
            )
            effective_text = context_summary

        task_builder = CustomerSupportCrewTasks(
            agents=self.agents,
            tools=self.tools,
        )

        # TASK 1 - INTAKE
        intake_task = task_builder.create_intake_task(effective_text)

        # TASK 2 - CLASSIFICATION
        classification_task = task_builder.create_classification_task(
            effective_text, intake_task
        )

        # TASK 3 - SENTIMENT
        sentiment_task = task_builder.create_sentiment_task(effective_text, intake_task)

        # TASK 4 - RETRIEVAL / RAG
        retrieval_task = task_builder.create_retrieval_task(
            effective_text, intake_task, classification_task
        )

        # TASK 5 - RESPONSE
        response_task = task_builder.create_response_task(
            effective_text, intake_task, classification_task, sentiment_task
        )

        # TASK 6 - ESCALATION
        escalation_task = task_builder.create_escalation_task(
            effective_text, intake_task, classification_task, sentiment_task
        )

        # TASK 7 - LEARNING
        learning_task = task_builder.create_learning_task()

        crew = Crew(
            agents=[
                self.agents["intake"],
                self.agents["classification"],
                self.agents["sentiment"],
                self.agents["retrieval"],
                self.agents["response"],
                self.agents["escalation"],
                self.agents["learning"],
            ],
            tasks=[
                intake_task,
                classification_task,
                sentiment_task,
                retrieval_task,
                response_task,
                escalation_task,
                learning_task,
            ],
            process=Process.sequential,
            verbose=True,
        )

        return crew

    # =====================================================
    # EXECUTE CREW
    # =====================================================

    def process_ticket(self, ticket_text, previous_context=None):

        print("\n" + "=" * 70)
        print("STARTING CREWAI SUPPORT WORKFLOW")
        print("=" * 70)

        print("\nCustomer Ticket:")
        print(ticket_text)

        print("\nBuilding Crew...")
        crew = self.build_crew(ticket_text, previous_context)

        print("\nCrew created successfully.")
        print(f"Agents: {len(crew.agents)}")
        print(f"Tasks: {len(crew.tasks)}")
        print("\nProcess: Sequential")

        print("\n" + "=" * 70)
        print("EXECUTING CREWAI WORKFLOW")
        print("=" * 70)

        crew_output = crew.kickoff()

        print("\n" + "=" * 70)
        print("CREWAI WORKFLOW COMPLETED")
        print("=" * 70)

        print("\nFinal Crew Output:")
        print(crew_output)

        # Task order matches the tasks= list in build_crew():
        # 0 intake, 1 classification, 2 sentiment, 3 retrieval,
        # 4 response, 5 escalation, 6 learning.
        intake = _safe_json_object(_task_raw(crew_output, 0))
        classification = _safe_json_object(_task_raw(crew_output, 1))
        sentiment = _safe_json_object(_task_raw(crew_output, 2))
        retrieval_results = _safe_json_list(_task_raw(crew_output, 3))
        response_text = _task_raw(crew_output, 4)  # plain text, not JSON
        escalation = _safe_json_object(_task_raw(crew_output, 5))
        learning = _safe_json_object(_task_raw(crew_output, 6))

        # --- Normalize field names to what the Streamlit UI expects ---
        # Intake tool returns "customer_intent"; UI reads "intent".
        intake["intent"] = intake.get("intent") or intake.get("customer_intent")
        intake["is_follow_up"] = bool(previous_context)

        classification["is_follow_up"] = bool(previous_context)

        # Sentiment tool returns signal *counts*, not a list of strings;
        # build a readable list from them so the UI's signals section
        # has something real to show instead of being silently empty.
        signal_parts = []
        if sentiment.get("very_negative_signals"):
            signal_parts.append(f"{sentiment['very_negative_signals']} very negative signal(s)")
        if sentiment.get("negative_signals"):
            signal_parts.append(f"{sentiment['negative_signals']} negative signal(s)")
        if sentiment.get("positive_signals"):
            signal_parts.append(f"{sentiment['positive_signals']} positive signal(s)")
        sentiment["signals"] = signal_parts

        # Escalation tool returns "escalation_score"; UI reads "score".
        escalation["score"] = escalation.get("score", escalation.get("escalation_score"))

        result = {
            "intake": intake,
            "classification": classification,
            "sentiment": sentiment,
            "retrieval": {"results": retrieval_results},
            "response": response_text,
            "escalation": escalation,
            "learning": learning,
            "raw_crew_output": str(crew_output),
        }

        return result


# =========================================================
# TEST
# =========================================================

if __name__ == "__main__":

    ticket = (
        "My wireless headphones arrived today, but the left "
        "earbud is not working even after charging it "
        "completely. I would like a replacement. "
        "Order ORD7824512."
    )

    try:
        support_crew = CustomerSupportCrew()
        result = support_crew.process_ticket(ticket)

        print("\n" + "=" * 70)
        print("CREWAI END-TO-END TEST SUCCESSFUL")
        print("=" * 70)

        print("\nThe ticket was processed using:")
        print("  [OK] CrewAI orchestration")
        print("  [OK] Groq GPT-OSS-120B")
        print("  [OK] Intake Agent")
        print("  [OK] Classification Agent")
        print("  [OK] Sentiment Agent")
        print("  [OK] Retrieval / RAG Agent")
        print("  [OK] Response Agent")
        print("  [OK] Escalation Agent")
        print("  [OK] Learning Agent")

    except Exception as error:
        print("\n" + "=" * 70)
        print("CREWAI EXECUTION ERROR")
        print("=" * 70)
        print("\nError type:")
        print(type(error).__name__)
        print("\nError:")
        print(str(error))