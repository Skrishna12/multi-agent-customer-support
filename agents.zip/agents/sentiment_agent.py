import re


class SentimentAgent:

    def __init__(self):

        self.very_negative_words = [
            "counterfeit",
            "fake",
            "stolen",
            "fraud",
            "scam",
            "terrible",
            "worst",
            "unacceptable",
            "angry",
            "furious",
            "cheated",
            "illegal",
            "threat",
            "dangerous",
            "hacked",
            "identity theft"
        ]


        self.negative_words = [
            "damaged",
            "broken",
            "defective",
            "missing",
            "failed",
            "error",
            "wrong",
            "disappointed",
            "frustrating",
            "frustrated",
            "delay",
            "delayed",
            "late",
            "not received",
            "haven't received",
            "hasn't arrived",
            "didn't arrive",
            "not arrived",
            "cannot",
            "can't",
            "unable",
            "not working",
            "doesn't work",
            "does not work",
            "malfunction",
            "cracked",
            "faulty",
            "problem",
            "issue",
            "complaint"
        ]


        self.positive_words = [
            "thank you",
            "thanks",
            "great",
            "excellent",
            "happy",
            "satisfied",
            "helpful",
            "good service",
            "resolved successfully",
            "fixed successfully",
            "appreciate your help"
        ]


    def analyze(self, text):

        text_lower = str(text).lower()


        # ==================================================
        # COUNT SIGNALS
        # ==================================================

        very_negative_count = sum(
            phrase in text_lower
            for phrase in self.very_negative_words
        )


        negative_count = sum(
            phrase in text_lower
            for phrase in self.negative_words
        )


        positive_count = sum(
            phrase in text_lower
            for phrase in self.positive_words
        )


        # ==================================================
        # SENTIMENT DECISION
        # ==================================================

        if very_negative_count >= 1:

            sentiment = "Very Negative"

            confidence = min(
                80 + (very_negative_count * 5),
                95
            )


        elif negative_count >= 2:

            sentiment = "Negative"

            confidence = min(
                65 + (negative_count * 5),
                90
            )


        elif negative_count == 1:

            sentiment = "Slightly Negative"

            confidence = 70


        elif positive_count >= 1:

            sentiment = "Positive"

            confidence = min(
                70 + (positive_count * 5),
                90
            )


        else:

            sentiment = "Neutral"

            confidence = 50


        return {

            "sentiment": sentiment,

            "confidence": round(
                confidence,
                2
            ),

            "negative_signals": negative_count,

            "very_negative_signals":
                very_negative_count,

            "positive_signals":
                positive_count
        }


# ==========================================================
# STANDALONE TEST
# ==========================================================

if __name__ == "__main__":

    agent = SentimentAgent()

    ticket = input(
        "\nEnter customer ticket: "
    )

    result = agent.analyze(ticket)


    print("\n")
    print("=" * 60)
    print("SENTIMENT AGENT")
    print("=" * 60)

    print(
        "\nSentiment:",
        result["sentiment"]
    )

    print(
        "Confidence:",
        str(
            result["confidence"]
        ) + "%"
    )

    print(
        "Negative signals:",
        result["negative_signals"]
    )

    print(
        "Very negative signals:",
        result["very_negative_signals"]
    )

    print(
        "Positive signals:",
        result["positive_signals"]
    )