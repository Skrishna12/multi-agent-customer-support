# agents/crewai_agents.py

import os

from crewai import Agent, LLM
from dotenv import load_dotenv

load_dotenv()


# =========================================================
# GROQ CONFIGURATION
# =========================================================

GROQ_API_KEY = os.getenv("GROQ_API_KEY")

if not GROQ_API_KEY:
    raise EnvironmentError(
        "GROQ_API_KEY environment variable is not configured."
    )


# Two model tiers on Groq:
# - fast_llm / retrieval_llm: openai/gpt-oss-20b for the 6 agents whose job
#   is "call the deterministic tool and echo its compact JSON back". These
#   agents don't need heavy reasoning, and the smaller 20b variant of the
#   same model family should carry a higher rate limit on this account's
#   tier than the 120b model, which is what was causing the repeated
#   rate-limit failures on a 7-task sequential crew.
#   NOTE: llama-3.1-8b-instant was tried first but returned "model not
#   found" - it's gated to Enterprise/Contact-Sales accounts on Groq, not
#   available on standard tiers. gpt-oss-20b is in the same family as the
#   120b model already working on this account, so it should be accessible.
# - response_llm: kept on openai/gpt-oss-120b since Response is the one agent
#   where generation quality actually matters.
# num_retries lets litellm auto-retry a transient 429 after the wait time
# Groq specifies, instead of failing the whole crew over a near-miss.

fast_llm = LLM(
    model="groq/openai/gpt-oss-20b",
    api_key=GROQ_API_KEY,
    temperature=0.1,
    max_tokens=220,
    num_retries=3,
)

retrieval_llm = LLM(
    model="groq/openai/gpt-oss-20b",
    api_key=GROQ_API_KEY,
    temperature=0.1,
    max_tokens=350,  # needs to echo up to 3 compact records + learning stats
    num_retries=3,
)

response_llm = LLM(
    model="groq/openai/gpt-oss-120b",
    api_key=GROQ_API_KEY,
    temperature=0.2,
    max_tokens=400,
    num_retries=3,
)

# Kept for backwards compatibility with any code importing `groq_llm` directly.
groq_llm = fast_llm


# =========================================================
# CREATE CREWAI AGENTS
# =========================================================

def create_crewai_agents():

    # -----------------------------------------------------
    # 1. INTAKE AGENT
    # -----------------------------------------------------

    intake_agent = Agent(
        role="Customer Support Intake Specialist",
        goal="Call the intake tool on the ticket and return its exact JSON output.",
        backstory="You extract structured ticket data using tools only. Never invent data.",
        llm=fast_llm,
        verbose=True,
        allow_delegation=False,
        max_iter=2,
    )

    # -----------------------------------------------------
    # 2. CLASSIFICATION AGENT
    # -----------------------------------------------------

    classification_agent = Agent(
        role="Support Ticket Classification Specialist",
        goal="Call the classification tool and return its exact JSON output.",
        backstory="You classify tickets using tools only. Never invent data.",
        llm=fast_llm,
        verbose=True,
        allow_delegation=False,
        max_iter=2,
    )

    # -----------------------------------------------------
    # 3. SENTIMENT AGENT
    # -----------------------------------------------------

    sentiment_agent = Agent(
        role="Customer Sentiment Analysis Specialist",
        goal="Call the sentiment tool and return its exact JSON output.",
        backstory="You determine sentiment using tools only. Never invent data.",
        llm=fast_llm,
        verbose=True,
        allow_delegation=False,
        max_iter=2,
    )

    # -----------------------------------------------------
    # 4. RETRIEVAL AGENT
    # -----------------------------------------------------

    retrieval_agent = Agent(
        role="Customer Support Knowledge Retrieval Specialist",
        goal="Call the retrieval tool and return its exact JSON output.",
        backstory="You retrieve relevant knowledge using tools only. Never invent data.",
        llm=retrieval_llm,
        verbose=True,
        allow_delegation=False,
        max_iter=2,
    )

    # -----------------------------------------------------
    # 5. RESPONSE AGENT (only agent doing real generation)
    # -----------------------------------------------------

    response_agent = Agent(
        role="Customer Support Response Specialist",
        goal=(
            "Generate an accurate, empathetic, personalized customer-facing "
            "response using the ticket context, classification, sentiment, "
            "and retrieved knowledge provided."
        ),
        backstory=(
            "You are a professional customer support representative. You "
            "write clear, empathetic replies and never claim an action has "
            "already occurred unless explicitly confirmed."
        ),
        llm=response_llm,
        verbose=True,
        allow_delegation=False,
        max_iter=2,
    )

    # -----------------------------------------------------
    # 6. ESCALATION AGENT
    # -----------------------------------------------------

    escalation_agent = Agent(
        role="Support Escalation Specialist",
        goal="Call the escalation tool and return its exact JSON output.",
        backstory="You decide escalation using tools only. Never invent data.",
        llm=fast_llm,
        verbose=True,
        allow_delegation=False,
        max_iter=2,
    )

    # -----------------------------------------------------
    # 7. LEARNING AGENT
    # -----------------------------------------------------

    learning_agent = Agent(
        role="Customer Support Learning and Analytics Specialist",
        goal="Call the learning analytics tool and return its exact JSON output.",
        backstory="You report on historical support performance using tools only.",
        llm=retrieval_llm,
        verbose=True,
        allow_delegation=False,
        max_iter=2,
    )

    return {
        "intake": intake_agent,
        "classification": classification_agent,
        "sentiment": sentiment_agent,
        "retrieval": retrieval_agent,
        "response": response_agent,
        "escalation": escalation_agent,
        "learning": learning_agent,
    }


# =========================================================
# INITIALIZE
# =========================================================

crewai_agents = create_crewai_agents()


# =========================================================
# TEST
# =========================================================

if __name__ == "__main__":

    print("\n" + "=" * 65)
    print("CREWAI + GROQ AGENT CONFIGURATION")
    print("=" * 65)

    print(f"\nLLM Model: {fast_llm.model}")
    print(f"Total Agents: {len(crewai_agents)}")

    print("\nAgents:")
    for name, agent in crewai_agents.items():
        print(f"  ✓ {name}: {agent.role}")

    print("\nCrewAI + Groq configuration successful.")