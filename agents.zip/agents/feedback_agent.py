import sys
import os

# Add project root to Python path
sys.path.append(
    os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))
    )
)

from database.support_database import SupportDatabase


class FeedbackAgent:

    def __init__(self):
        self.database = SupportDatabase()

    def collect_feedback(self, ticket_id):

        print("\n" + "=" * 60)
        print("CUSTOMER FEEDBACK")
        print("=" * 60)

        helpful_input = input(
            "\nWas the response helpful? (yes/no): "
        ).strip().lower()

        resolved_input = input(
            "Was your issue resolved? (yes/no): "
        ).strip().lower()

        while True:

            try:

                satisfaction = float(
                    input(
                        "Customer satisfaction (1-5): "
                    )
                )

                if 1 <= satisfaction <= 5:
                    break

                print(
                    "Please enter a value between 1 and 5."
                )

            except ValueError:

                print(
                    "Please enter a number between 1 and 5."
                )

        comments = input(
            "Additional comments (optional): "
        ).strip()

        helpful = 1 if helpful_input == "yes" else 0

        resolved = 1 if resolved_input == "yes" else 0

        self.database.save_feedback(
            ticket_id=ticket_id,
            helpful=helpful,
            resolved=resolved,
            customer_satisfaction=satisfaction,
            comments=comments
        )

        print("\nFeedback saved successfully.")


if __name__ == "__main__":

    agent = FeedbackAgent()

    ticket_id = int(
        input(
            "\nEnter database ticket ID: "
        )
    )

    agent.collect_feedback(ticket_id)