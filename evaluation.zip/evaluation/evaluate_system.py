import os
import sys
import json

import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report
)


# =========================================================
# PROJECT PATH
# =========================================================

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

if PROJECT_ROOT not in sys.path:
    sys.path.append(PROJECT_ROOT)


# =========================================================
# LOAD DATA
# =========================================================

DATA_PATH = os.path.join(
    PROJECT_ROOT,
    "data",
    "support_tickets_10k.csv"
)

df = pd.read_csv(DATA_PATH)


# =========================================================
# DATASET INFORMATION
# =========================================================

print("\n" + "=" * 70)
print("MULTI-AGENT CUSTOMER SUPPORT — SYSTEM EVALUATION")
print("=" * 70)

print("\nDataset:")
print(f"Total tickets: {len(df)}")


# =========================================================
# DATASET-BASED BUSINESS METRICS
# =========================================================

print("\n" + "-" * 70)
print("DATASET / OPERATIONAL METRICS")
print("-" * 70)


total_tickets = len(df)

auto_resolved = (
    df["auto_resolved"]
    .astype(str)
    .str.lower()
    .isin(["true", "1", "yes"])
    .sum()
)

escalated = (
    df["escalated"]
    .astype(str)
    .str.lower()
    .isin(["true", "1", "yes"])
    .sum()
)

automation_rate = (
    auto_resolved / total_tickets * 100
)

escalation_rate = (
    escalated / total_tickets * 100
)


print(
    f"\nAuto-resolved tickets: "
    f"{auto_resolved}/{total_tickets}"
)

print(
    f"Automation rate: "
    f"{automation_rate:.2f}%"
)

print(
    f"\nEscalated tickets: "
    f"{escalated}/{total_tickets}"
)

print(
    f"Escalation rate: "
    f"{escalation_rate:.2f}%"
)


# =========================================================
# RESOLUTION TIME
# =========================================================

if "resolution_days" in df.columns:

    avg_resolution_days = (
        pd.to_numeric(
            df["resolution_days"],
            errors="coerce"
        )
        .mean()
    )

    print(
        f"\nAverage resolution time: "
        f"{avg_resolution_days:.2f} days"
    )


# =========================================================
# CUSTOMER SATISFACTION
# =========================================================

if "customer_satisfaction_score" in df.columns:

    satisfaction = pd.to_numeric(
        df["customer_satisfaction_score"],
        errors="coerce"
    )

    avg_satisfaction = satisfaction.mean()

    print(
        f"Average customer satisfaction: "
        f"{avg_satisfaction:.2f}/5"
    )


# =========================================================
# CLASSIFICATION MODELS
# =========================================================

from models.predict import predict_ticket


print("\n" + "-" * 70)
print("CLASSIFICATION EVALUATION")
print("-" * 70)


# ---------------------------------------------------------
# CATEGORY
# ---------------------------------------------------------

print("\nEvaluating category classification...")

category_predictions = []

for text in df["ticket_text"]:

    try:

        prediction = predict_ticket(text)

        category_predictions.append(
            prediction["category"]
        )

    except Exception:

        category_predictions.append(
            "UNKNOWN"
        )


actual_category = df["ticket_category"]

category_accuracy = accuracy_score(
    actual_category,
    category_predictions
)

category_precision = precision_score(
    actual_category,
    category_predictions,
    average="weighted",
    zero_division=0
)

category_recall = recall_score(
    actual_category,
    category_predictions,
    average="weighted",
    zero_division=0
)

category_f1 = f1_score(
    actual_category,
    category_predictions,
    average="weighted",
    zero_division=0
)


print(
    f"\nCategory Accuracy: "
    f"{category_accuracy:.4f}"
)

print(
    f"Category Precision: "
    f"{category_precision:.4f}"
)

print(
    f"Category Recall: "
    f"{category_recall:.4f}"
)

print(
    f"Category F1: "
    f"{category_f1:.4f}"
)


# ---------------------------------------------------------
# PRIORITY
# ---------------------------------------------------------

print("\nEvaluating priority classification...")

priority_predictions = []

for text in df["ticket_text"]:

    try:

        prediction = predict_ticket(text)

        priority_predictions.append(
            prediction["priority"]
        )

    except Exception:

        priority_predictions.append(
            "UNKNOWN"
        )


actual_priority = df["priority"]

priority_accuracy = accuracy_score(
    actual_priority,
    priority_predictions
)

priority_precision = precision_score(
    actual_priority,
    priority_predictions,
    average="weighted",
    zero_division=0
)

priority_recall = recall_score(
    actual_priority,
    priority_predictions,
    average="weighted",
    zero_division=0
)

priority_f1 = f1_score(
    actual_priority,
    priority_predictions,
    average="weighted",
    zero_division=0
)


print(
    f"\nPriority Accuracy: "
    f"{priority_accuracy:.4f}"
)

print(
    f"Priority Precision: "
    f"{priority_precision:.4f}"
)

print(
    f"Priority Recall: "
    f"{priority_recall:.4f}"
)

print(
    f"Priority F1: "
    f"{priority_f1:.4f}"
)


# =========================================================
# MODEL CONFIDENCE
# =========================================================

if "confidence_score" in df.columns:

    confidence = pd.to_numeric(
        df["confidence_score"],
        errors="coerce"
    )

    print("\n" + "-" * 70)
    print("CONFIDENCE ANALYSIS")
    print("-" * 70)

    print(
        f"\nAverage dataset confidence: "
        f"{confidence.mean():.2f}"
    )

    print(
        f"Minimum confidence: "
        f"{confidence.min():.2f}"
    )

    print(
        f"Maximum confidence: "
        f"{confidence.max():.2f}"
    )


# =========================================================
# CATEGORY DISTRIBUTION
# =========================================================

print("\n" + "-" * 70)
print("CATEGORY DISTRIBUTION")
print("-" * 70)

category_distribution = (
    df["ticket_category"]
    .value_counts()
)

print(
    category_distribution.to_string()
)


# =========================================================
# PRIORITY DISTRIBUTION
# =========================================================

print("\n" + "-" * 70)
print("PRIORITY DISTRIBUTION")
print("-" * 70)

priority_distribution = (
    df["priority"]
    .value_counts()
)

print(
    priority_distribution.to_string()
)


# =========================================================
# SENTIMENT DISTRIBUTION
# =========================================================

print("\n" + "-" * 70)
print("SENTIMENT DISTRIBUTION")
print("-" * 70)

sentiment_distribution = (
    df["sentiment"]
    .value_counts()
)

print(
    sentiment_distribution.to_string()
)


# =========================================================
# SAVE RESULTS
# =========================================================

results = {

    "dataset": {
        "total_tickets": int(total_tickets)
    },

    "operations": {
        "auto_resolved": int(auto_resolved),
        "automation_rate_percent": round(
            automation_rate,
            2
        ),
        "escalated": int(escalated),
        "escalation_rate_percent": round(
            escalation_rate,
            2
        )
    },

    "classification": {

        "category": {
            "accuracy": round(
                category_accuracy,
                4
            ),
            "precision": round(
                category_precision,
                4
            ),
            "recall": round(
                category_recall,
                4
            ),
            "f1": round(
                category_f1,
                4
            )
        },

        "priority": {
            "accuracy": round(
                priority_accuracy,
                4
            ),
            "precision": round(
                priority_precision,
                4
            ),
            "recall": round(
                priority_recall,
                4
            ),
            "f1": round(
                priority_f1,
                4
            )
        }
    }
}


if "resolution_days" in df.columns:

    results["operations"][
        "average_resolution_days"
    ] = round(
        float(avg_resolution_days),
        2
    )


if "customer_satisfaction_score" in df.columns:

    results["operations"][
        "average_customer_satisfaction"
    ] = round(
        float(avg_satisfaction),
        2
    )


output_path = os.path.join(
    PROJECT_ROOT,
    "evaluation",
    "evaluation_results.json"
)

with open(
    output_path,
    "w",
    encoding="utf-8"
) as file:

    json.dump(
        results,
        file,
        indent=4
    )


print("\n" + "=" * 70)
print("EVALUATION COMPLETE")
print("=" * 70)

print(
    f"\nResults saved to:\n{output_path}"
)