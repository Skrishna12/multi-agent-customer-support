import os
import sys
import json
import statistics

import pandas as pd


# =========================================================
# PROJECT PATH
# =========================================================

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

if PROJECT_ROOT not in sys.path:
    sys.path.append(PROJECT_ROOT)


# =========================================================
# IMPORT RETRIEVAL AGENT
# =========================================================

from rag.retrieval_agent import RetrievalAgent


# =========================================================
# LOAD DATA
# =========================================================

DATA_PATH = os.path.join(
    PROJECT_ROOT,
    "data",
    "support_tickets_10k.csv"
)

df = pd.read_csv(DATA_PATH)


# =========================================================
# INITIALIZATION
# =========================================================

print("\n" + "=" * 70)
print("MULTI-AGENT CUSTOMER SUPPORT — RAG EVALUATION")
print("=" * 70)

print(
    f"\nEvaluation dataset: {len(df)} tickets"
)

print(
    "\nLoading FAISS retrieval system..."
)

retriever = RetrievalAgent()

print("RAG system loaded successfully.")


# =========================================================
# STRATIFIED SAMPLE
# =========================================================

SAMPLE_PER_CATEGORY = 100

sample_parts = []

for category in df["ticket_category"].unique():

    category_data = df[
        df["ticket_category"] == category
    ]

    sample_size = min(
        SAMPLE_PER_CATEGORY,
        len(category_data)
    )

    category_sample = category_data.sample(
        n=sample_size,
        random_state=42
    )

    sample_parts.append(
        category_sample
    )


sample_df = pd.concat(
    sample_parts,
    ignore_index=True
)


print(
    f"\nEvaluation sample size: "
    f"{len(sample_df)} tickets"
)


# =========================================================
# STORAGE
# =========================================================

top1_scores = []

top3_scores = []

top5_scores = []

retrieval_success = []

faq_counts = []

ticket_counts = []

category_match_counts = []

category_top1_scores = {}


# =========================================================
# EVALUATION
# =========================================================

print("\n" + "-" * 70)
print("RUNNING RAG EVALUATION")
print("-" * 70)


for index, row in sample_df.iterrows():

    query = str(
        row["ticket_text"]
    )

    expected_category = str(
        row["ticket_category"]
    )

    try:

        results = retriever.retrieve(
            query,
            category=expected_category,
            top_k=5
        )


        # -------------------------------------------------
        # NO RESULTS
        # -------------------------------------------------

        if not results:

            retrieval_success.append(0)

            top1_scores.append(0)

            top3_scores.append(0)

            top5_scores.append(0)

            faq_counts.append(0)

            ticket_counts.append(0)

            category_match_counts.append(0)

            continue


        retrieval_success.append(1)


        # -------------------------------------------------
        # SIMILARITY SCORES
        # -------------------------------------------------

        scores = [

            float(
                result["similarity_score"]
            )

            for result in results
        ]


        # Top-1
        top1 = scores[0]

        top1_scores.append(top1)


        # Top-3
        top3_scores.append(
            statistics.mean(
                scores[:3]
            )
        )


        # Top-5
        top5_scores.append(
            statistics.mean(
                scores[:5]
            )
        )


        # -------------------------------------------------
        # CATEGORY LEVEL TOP-1
        # -------------------------------------------------

        if expected_category not in category_top1_scores:

            category_top1_scores[
                expected_category
            ] = []

        category_top1_scores[
            expected_category
        ].append(top1)


        # -------------------------------------------------
        # SOURCE DISTRIBUTION
        # -------------------------------------------------

        faq_count = sum(

            1

            for result in results

            if str(
                result["source_type"]
            ).upper() == "FAQ"
        )


        ticket_count = sum(

            1

            for result in results

            if str(
                result["source_type"]
            ).upper() == "TICKET"
        )


        faq_counts.append(
            faq_count
        )

        ticket_counts.append(
            ticket_count
        )


        # -------------------------------------------------
        # CATEGORY MATCH
        # -------------------------------------------------

        category_matches = sum(

            1

            for result in results

            if str(
                result["category"]
            )
            == expected_category
        )


        category_match_counts.append(
            category_matches
        )


    except Exception as error:

        print(
            f"\nWarning: ticket "
            f"{index + 1} failed: "
            f"{error}"
        )

        retrieval_success.append(0)

        top1_scores.append(0)

        top3_scores.append(0)

        top5_scores.append(0)

        faq_counts.append(0)

        ticket_counts.append(0)

        category_match_counts.append(0)


    # -----------------------------------------------------
    # PROGRESS
    # -----------------------------------------------------

    if (index + 1) % 100 == 0:

        print(
            f"Processed "
            f"{index + 1}/"
            f"{len(sample_df)} tickets..."
        )


# =========================================================
# AGGREGATE METRICS
# =========================================================

total_evaluated = len(sample_df)

successful_retrievals = sum(
    retrieval_success
)

retrieval_coverage = (

    successful_retrievals
    / total_evaluated
    * 100

    if total_evaluated > 0
    else 0
)


average_top1 = statistics.mean(
    top1_scores
)

average_top3 = statistics.mean(
    top3_scores
)

average_top5 = statistics.mean(
    top5_scores
)


# =========================================================
# SOURCE DISTRIBUTION
# =========================================================

total_faq_results = sum(
    faq_counts
)

total_ticket_results = sum(
    ticket_counts
)

total_results = (
    total_faq_results
    + total_ticket_results
)


faq_percentage = (

    total_faq_results
    / total_results
    * 100

    if total_results > 0
    else 0
)


ticket_percentage = (

    total_ticket_results
    / total_results
    * 100

    if total_results > 0
    else 0
)


# =========================================================
# CATEGORY MATCH RATE
# =========================================================

total_possible_results = (
    total_evaluated * 5
)

category_match_rate = (

    sum(category_match_counts)
    / total_possible_results
    * 100

    if total_possible_results > 0
    else 0
)


# =========================================================
# PRINT RESULTS
# =========================================================

print("\n" + "=" * 70)
print("RAG EVALUATION RESULTS")
print("=" * 70)


print(
    f"\nTickets evaluated: "
    f"{total_evaluated}"
)


print(
    f"\nRetrieval coverage: "
    f"{retrieval_coverage:.2f}%"
)


print(
    f"\nAverage Top-1 similarity: "
    f"{average_top1:.4f}"
)


print(
    f"Average Top-3 similarity: "
    f"{average_top3:.4f}"
)


print(
    f"Average Top-5 similarity: "
    f"{average_top5:.4f}"
)


print(
    f"\nCategory-matched results: "
    f"{category_match_rate:.2f}%"
)


# =========================================================
# SOURCE BREAKDOWN
# =========================================================

print("\n" + "-" * 70)
print("RAG SOURCE BREAKDOWN")
print("-" * 70)


print(
    f"\nFAQ results: "
    f"{total_faq_results}"
)


print(
    f"Historical ticket results: "
    f"{total_ticket_results}"
)


print(
    f"\nFAQ percentage: "
    f"{faq_percentage:.2f}%"
)


print(
    f"Historical ticket percentage: "
    f"{ticket_percentage:.2f}%"
)


# =========================================================
# CATEGORY-LEVEL RESULTS
# =========================================================

print("\n" + "-" * 70)
print("CATEGORY-LEVEL TOP-1 SIMILARITY")
print("-" * 70)


category_results = {}


for category in sorted(
    category_top1_scores.keys()
):

    scores = category_top1_scores[
        category
    ]

    if scores:

        average_score = statistics.mean(
            scores
        )

    else:

        average_score = 0


    category_results[category] = round(
        average_score,
        4
    )


    print(
        f"\n{category}: "
        f"{average_score:.4f}"
    )


# =========================================================
# QUALITY ASSESSMENT
# =========================================================

if average_top1 >= 0.70:

    quality = "Excellent"

elif average_top1 >= 0.60:

    quality = "Good"

elif average_top1 >= 0.50:

    quality = "Moderate"

else:

    quality = "Needs Improvement"


print("\n" + "-" * 70)

print(
    f"\nOverall RAG quality assessment: "
    f"{quality}"
)


# =========================================================
# SAVE RESULTS
# =========================================================

results = {

    "evaluation": {

        "total_dataset_tickets": int(
            len(df)
        ),

        "sample_size": int(
            total_evaluated
        ),

        "retrieval_coverage_percent": round(
            retrieval_coverage,
            2
        ),

        "average_top1_similarity": round(
            average_top1,
            4
        ),

        "average_top3_similarity": round(
            average_top3,
            4
        ),

        "average_top5_similarity": round(
            average_top5,
            4
        ),

        "category_match_rate_percent": round(
            category_match_rate,
            2
        )
    },

    "source_distribution": {

        "faq_results": int(
            total_faq_results
        ),

        "historical_ticket_results": int(
            total_ticket_results
        ),

        "faq_percentage": round(
            faq_percentage,
            2
        ),

        "historical_ticket_percentage": round(
            ticket_percentage,
            2
        )
    },

    "category_top1_similarity":
        category_results,

    "quality_assessment":
        quality
}


# =========================================================
# SAVE JSON
# =========================================================

output_path = os.path.join(
    PROJECT_ROOT,
    "evaluation",
    "rag_evaluation_results.json"
)


with open(
    output_path,
    "w",
    encoding="utf-8"
) as file:

    json.dump(
        results,
        file,
        indent=4
    )


# =========================================================
# COMPLETE
# =========================================================

print("\n" + "=" * 70)
print("RAG EVALUATION COMPLETE")
print("=" * 70)

print(
    f"\nResults saved to:\n"
    f"{output_path}"
)