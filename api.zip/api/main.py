import os
import sys
from typing import Any, Dict, Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import uvicorn


# =========================================================
# PROJECT PATH
# =========================================================

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


# =========================================================
# SERVICE
# =========================================================

from agents.crewai_support_service import CrewAISupportService


# =========================================================
# FASTAPI APP
# =========================================================

app = FastAPI(
    title="Multi-Agent Customer Support Intelligence API",
    description=(
        "Multi-agent eCommerce customer support system using "
        "ML classification, sentiment analysis, RAG, response "
        "generation, escalation, learning, and CrewAI orchestration."
    ),
    version="1.0.0"
)


# =========================================================
# SERVICE INSTANCE
# =========================================================

support_service = CrewAISupportService()


# =========================================================
# REQUEST MODELS
# =========================================================

class TicketRequest(BaseModel):
    ticket_text: str = Field(
        ...,
        min_length=1,
        description="Customer support ticket or follow-up message."
    )

    previous_context: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Context from the previous conversation turn."
    )


class FeedbackRequest(BaseModel):
    rating: int = Field(
        ...,
        ge=1,
        le=5,
        description="Customer feedback rating from 1 to 5."
    )

    feedback_text: Optional[str] = Field(
        default="",
        description="Optional written feedback."
    )


# =========================================================
# ROOT
# =========================================================

@app.get("/")
def root():
    return {
        "service": "Multi-Agent Customer Support Intelligence Platform",
        "status": "running",
        "version": "1.0.0",
        "features": [
            "Intake Agent",
            "Classification Agent",
            "Sentiment Agent",
            "Retrieval / RAG Agent",
            "Response Agent",
            "Escalation Agent",
            "Learning Agent",
            "CrewAI Orchestration",
            "Conversation Memory",
            "Feedback",
            "SQLite Logging"
        ]
    }


# =========================================================
# HEALTH CHECK
# =========================================================

@app.get("/health")
def health():
    return {
        "status": "healthy",
        "service": "customer-support-api"
    }


# =========================================================
# PROCESS TICKET
# =========================================================

@app.post("/process")
def process_ticket(request: TicketRequest):

    try:

        result = support_service.process_ticket(
            ticket_text=request.ticket_text,
            previous_context=request.previous_context
        )

        return result

    except ValueError as e:

        raise HTTPException(
            status_code=400,
            detail=str(e)
        )

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Ticket processing failed: {str(e)}"
        )


# =========================================================
# CREATE / PROCESS TICKET
# =========================================================

@app.post("/ticket")
def create_ticket(request: TicketRequest):

    try:

        result = support_service.process_ticket(
            ticket_text=request.ticket_text,
            previous_context=request.previous_context
        )

        return result

    except ValueError as e:

        raise HTTPException(
            status_code=400,
            detail=str(e)
        )

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Ticket processing failed: {str(e)}"
        )


# =========================================================
# GET TICKET
# =========================================================

@app.get("/ticket/{ticket_id}")
def get_ticket(ticket_id: int):

    try:

        ticket = support_service.pipeline.database.get_ticket(
            ticket_id
        )

        if ticket is None:

            raise HTTPException(
                status_code=404,
                detail=f"Ticket {ticket_id} not found."
            )

        return ticket

    except HTTPException:
        raise

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Could not retrieve ticket: {str(e)}"
        )


# =========================================================
# GET AGENT LOGS
# =========================================================

@app.get("/logs/{ticket_id}")
def get_agent_logs(ticket_id: int):

    try:

        logs = support_service.pipeline.database.get_agent_logs(
            ticket_id
        )

        return {
            "ticket_id": ticket_id,
            "agent_count": len(logs),
            "logs": logs
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Could not retrieve agent logs: {str(e)}"
        )


# =========================================================
# GET RETRIEVAL LOGS
# =========================================================

@app.get("/retrieval/{ticket_id}")
def get_retrieval_logs(ticket_id: int):

    try:

        logs = support_service.pipeline.database.get_retrieval_logs(
            ticket_id
        )

        return {
            "ticket_id": ticket_id,
            "retrieval_count": len(logs),
            "logs": logs
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Could not retrieve retrieval logs: {str(e)}"
        )


# =========================================================
# FEEDBACK
# =========================================================

@app.post("/feedback/{ticket_id}")
def submit_feedback(
    ticket_id: int,
    request: FeedbackRequest
):

    try:

        # Verify ticket exists
        ticket = support_service.pipeline.database.get_ticket(
            ticket_id
        )

        if ticket is None:

            raise HTTPException(
                status_code=404,
                detail=f"Ticket {ticket_id} not found."
            )

        support_service.pipeline.database.save_feedback(
            ticket_id=ticket_id,
            rating=request.rating,
            feedback_text=request.feedback_text
        )

        return {
            "status": "success",
            "ticket_id": ticket_id,
            "rating": request.rating,
            "feedback_text": request.feedback_text
        }

    except HTTPException:
        raise

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Could not save feedback: {str(e)}"
        )


# =========================================================
# GET FEEDBACK
# =========================================================

@app.get("/feedback/{ticket_id}")
def get_feedback(ticket_id: int):

    try:

        feedback = support_service.pipeline.database.get_feedback(
            ticket_id
        )

        return {
            "ticket_id": ticket_id,
            "feedback": feedback
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Could not retrieve feedback: {str(e)}"
        )


# =========================================================
# STATISTICS
# =========================================================

@app.get("/stats")
def get_stats():

    try:

        database = support_service.pipeline.database

        ticket_count = database.get_ticket_count()

        return {
            "tickets_processed": ticket_count,
            "agent_logs": database.get_agent_log_count()
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Could not retrieve statistics: {str(e)}"
        )


# =========================================================
# RUN SERVER
# =========================================================

if __name__ == "__main__":

    uvicorn.run(
        "api.main:app",
        host="127.0.0.1",
        port=8000,
        reload=False
    )